export type Lang = 'th' | 'en';

export interface CreditEntry {
  id: string;
  name: string;
  subtitle: string;
  roleTh: string;
  roleEn: string;
  bioTh: string;
  bioEn: string;
  coverImage: string;
  coverKind: 'portrait' | 'logo';
  coverBg?: string;
  objectPosition?: string;
  email?: string;
}

export const CREDIT_ITEMS: CreditEntry[] = [
  {
    id: 'pongsakorn',
    name: 'Pongsakorn Sawangsaeng',
    subtitle: 'sawangsaengpongsakorn@gmail.com',
    roleTh: 'ออกแบบ · คิดค้นการสร้าง',
    roleEn: 'Design · Concept Creator',
    bioTh: 'ผู้ออกแบบแนวคิด ประสบการณ์ผู้ใช้ และโครงสร้างเครื่องมือ Opus Studio',
    bioEn: 'Creator, UX concept designer, and product visionary behind Opus Studio.',
    coverImage: '/assets/aistudio/lv_0_20261111140719_295c771a.jpg',
    coverKind: 'portrait',
    objectPosition: 'object-[50%_46%]',
    email: 'sawangsaengpongsakorn@gmail.com',
  },
  {
    id: 'narakhnu',
    name: 'narakhnu79@gmail.com',
    subtitle: 'narakhnu79@gmail.com',
    roleTh: 'ผู้ร่วมสร้าง · เครดิต',
    roleEn: 'Contributor · Credit',
    bioTh: 'ผู้ร่วมพัฒนา ทดสอบระบบ และสนับสนุนการสร้างสรรค์โปรเจกต์',
    bioEn: 'Co-creator, feature contributor, and testing supporter.',
    coverImage: '/assets/aistudio/alya-1_a8de25fc.jpg',
    coverKind: 'portrait',
    objectPosition: 'object-[50%_38%]',
    email: 'narakhnu79@gmail.com',
  },
  {
    id: 'claude',
    name: 'AI Claude',
    subtitle: 'by Anthropic',
    roleTh: 'ผู้ช่วยสร้างและพัฒนา',
    roleEn: 'AI Build & Development',
    bioTh: 'ผู้ช่วยเขียนโค้ด จัดการแท็กไฟล์เสียง Ogg/Opus และปรับแต่งส่วนติดต่อผู้ใช้',
    bioEn: 'AI engineering partner for audio tag serialization and UI craftsmanship.',
    coverImage: '/assets/aistudio/images__4__07ae82fc.jpeg',
    coverKind: 'logo',
    coverBg: '#d26846',
  },
  {
    id: 'gemini',
    name: 'AI Gemini',
    subtitle: 'by Google',
    roleTh: 'ผู้ช่วยสร้างและพัฒนา',
    roleEn: 'AI Build & Development',
    bioTh: 'ผู้ช่วยตรวจสอบบัค ออกแบบสถาปัตยกรรมเว็บ และปรับปรุงประสบการณ์การใช้งาน',
    bioEn: 'AI engineering partner for bug fixing, architecture, and visual polish.',
    coverImage: '/assets/aistudio/images__3__83491943.jpeg',
    coverKind: 'logo',
    coverBg: '#ffffff',
  },
];

export interface WelcomeFeature {
  num: string;
  titleTh: string;
  titleEn: string;
  descTh: string;
  descEn: string;
}

export const WELCOME_FEATURES: WelcomeFeature[] = [
  {
    num: '01',
    titleTh: 'ใช้ง่าย ในไม่กี่ขั้นตอน',
    titleEn: 'Simple & Fast Workflow',
    descTh: 'ลากไฟล์ .opus, .ogg หรือ .mp3 มาวาง แก้ชื่อเพลง ศิลปิน อัลบั้ม และปกเพลงได้ทันที',
    descEn: 'Drop .opus, .ogg, or .mp3 files to edit title, artist, album, and cover art in seconds.',
  },
  {
    num: '02',
    titleTh: 'ฟรี 100% ไม่มีค่าใช้จ่าย',
    titleEn: '100% Free to Use',
    descTh: 'ใช้งานได้ครบทุกฟังก์ชันโดยไม่ต้องสมัครสมาชิก ไม่จำกัดจำนวนไฟล์ และไม่มีลายน้ำ',
    descEn: 'Every feature is completely free with no account required and unlimited file edits.',
  },
  {
    num: '03',
    titleTh: 'ปลอดภัย ประมวลผลในเครื่อง',
    titleEn: 'Private & Browser-Based',
    descTh: 'ไฟล์เสียงของคุณไม่ถูกอัปโหลดขึ้นเซิร์ฟเวอร์ การแก้ไขแท็กและปกทำในเบราว์เซอร์โดยตรง',
    descEn: 'Your audio files stay on your device; all tag and cover editing runs locally in your browser.',
  },
  {
    num: '04',
    titleTh: 'เชื่อมข้อมูล YouTube & Spotify',
    titleEn: 'YouTube & Spotify Lookup',
    descTh: 'ดึงชื่อคลิป ชื่อช่อง และภาพปกจาก YouTube หรือดึงปกเพลงจาก Spotify มาใส่ในแท็กได้ทันที',
    descEn: 'Look up YouTube clip titles, channels, and thumbnails or fetch Spotify metadata directly into tags.',
  },
];

export interface FaqEntry {
  q: string;
  keywords: string[];
  a: string;
}

export const FAQ_TH: FaqEntry[] = [
  {
    q: 'เว็บนี้ใช้งานยังไง',
    keywords: ['ใช้งาน', 'วิธี', 'เริ่ม', 'ยังไง', 'how'],
    a: 'กดปุ่ม "เริ่มต้นใช้งาน" แล้วเลือกใช้งานได้ 2 แท็บ:\n1) แท็กเพลง – เลือกไฟล์ .opus, .ogg หรือ .mp3 แก้ชื่อเพลง ศิลปิน อัลบั้ม ปก แล้วกดบันทึก\n2) ข้อมูล YouTube – วางลิงก์คลิปเพื่อดูและคัดลอกชื่อคลิป ชื่อช่อง หรือส่งเข้าแท็บแท็กเพลงได้ทันที',
  },
  {
    q: 'ไฟล์ของฉันถูกอัปโหลดไหม',
    keywords: ['อัปโหลด', 'อัพโหลด', 'ปลอดภัย', 'ความเป็นส่วนตัว', 'upload', 'privacy'],
    a: 'การแก้แท็กทำในเบราว์เซอร์ของคุณทั้งหมด ไฟล์เสียงที่เลือกไม่ถูกอัปโหลดไปยังเซิร์ฟเวอร์\n\nเฉพาะฟีเจอร์ดึงข้อมูลจากลิงก์ YouTube หรือ Spotify เท่านั้นที่จะส่งลิงก์ที่คุณวางออกไปเพื่อดึงชื่อและภาพปกกลับมาให้',
  },
  {
    q: 'Opus คืออะไร',
    keywords: ['opus', 'โอปัส', 'ฟอร์แมต', 'format'],
    a: 'Opus เป็นรูปแบบเสียงที่บีบอัดได้มีประสิทธิภาพสูง ไฟล์ .opus (Ogg Opus) ใช้กันแพร่หลายในบริการสตรีมมิงและแอปแชต เว็บนี้รองรับการแก้ไขแท็กและปกเพลงของทั้ง .opus, .ogg และ .mp3',
  },
  {
    q: 'ดึงข้อมูล Spotify/YouTube ไม่ได้',
    keywords: ['ดึง', 'spotify', 'youtube', 'ยูทูป', 'สปอติฟาย', 'ไม่ได้', 'error', 'ผิดพลาด'],
    a: 'ลองตรวจดังนี้:\n• ลิงก์ต้องเป็นของเพลงเดี่ยว (Spotify /track/…) หรือคลิปเดี่ยว (YouTube) ไม่ใช่เพลย์ลิสต์\n• ต้องเชื่อมต่ออินเทอร์เน็ต\n• คลิปที่ตั้งเป็นส่วนตัวหรือถูกจำกัดการฝังอาจดึงไม่ได้',
  },
  {
    q: 'ใช้งานฟรีจริงไหม มีข้อจำกัดอะไรบ้าง',
    keywords: ['ฟรี', 'เสียเงิน', 'ราคา', 'จำกัด', 'free', 'cost'],
    a: 'ใช้งานฟรี 100% ครับ ไม่มีค่าใช้จ่าย ไม่ต้องสมัครสมาชิก และไม่จำกัดจำนวนไฟล์ในการแก้ไขแท็ก',
  },
  {
    q: 'รองรับไฟล์อะไรบ้าง',
    keywords: ['รองรับ', 'ไฟล์อะไร', 'นามสกุล', 'ogg', 'mp3'],
    a: '• แท็กเพลง: รับไฟล์ .opus, .ogg และ .mp3\n• ปกเพลง: รับไฟล์รูปภาพทั่วไป (JPG, PNG, WebP)',
  },
];

export const FAQ_EN: FaqEntry[] = [
  {
    q: 'How do I use this site?',
    keywords: ['use', 'how', 'start', 'guide', 'tutorial'],
    a: 'Click "Get Started" and choose between 2 tabs:\n1) Tag Music – pick an .opus, .ogg, or .mp3 file, edit title, artist, album, and cover art, then save.\n2) YouTube Info – paste a video link to copy its title/channel or send them straight to the tag editor.',
  },
  {
    q: 'Are my files uploaded?',
    keywords: ['upload', 'privacy', 'safe', 'secure', 'private'],
    a: 'Tag editing happens entirely in your browser; the audio files you pick are never uploaded.\n\nOnly YouTube and Spotify link lookups send the pasted URL to retrieve public metadata and cover thumbnails.',
  },
  {
    q: 'What is Opus?',
    keywords: ['opus', 'format', 'codec'],
    a: 'Opus is a high-efficiency audio format (.opus / Ogg Opus) widely used by streaming platforms and chat apps. Opus Studio lets you edit metadata tags and cover art for .opus, .ogg, and .mp3 files.',
  },
  {
    q: 'Spotify/YouTube lookup fails',
    keywords: ['fetch', 'spotify', 'youtube', 'fail', 'error', 'cannot', 'not working'],
    a: 'Please check:\n• The link must point to a single Spotify track (/track/…) or a single YouTube video, not a playlist.\n• You need an active internet connection.\n• Private or embed-restricted videos may be unavailable.',
  },
  {
    q: 'Is it really free?',
    keywords: ['free', 'cost', 'price', 'limit', 'paid'],
    a: 'Yes, 100% free! No sign-up required, no watermarks, and no limits on how many files you edit.',
  },
  {
    q: 'Which files are supported?',
    keywords: ['support', 'file type', 'extension', 'ogg', 'mp3', 'format'],
    a: '• Audio tags: .opus, .ogg, and .mp3\n• Cover art: common image files (JPG, PNG, WebP)',
  },
];

export function matchFaqReply(query: string, lang: Lang): string {
  const list = lang === 'en' ? FAQ_EN : FAQ_TH;
  const normalized = query.toLowerCase();
  let bestIdx = -1;
  let bestScore = 0;

  list.forEach((item, idx) => {
    const score = item.keywords.filter((kw) => normalized.includes(kw)).length;
    if (score > bestScore) {
      bestScore = score;
      bestIdx = idx;
    }
  });

  if (bestIdx >= 0) return list[bestIdx].a;
  return lang === 'en'
    ? 'Sorry, I did not recognize that question. Try picking one of the topics below.'
    : 'ขออภัยครับ ผมยังไม่เข้าใจคำถามนี้ ลองเลือกจากหัวข้อด้านล่างได้เลยครับ';
}
