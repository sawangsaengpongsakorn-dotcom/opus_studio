import { Mail, X } from 'lucide-react';
import { CREDIT_ITEMS, type CreditEntry, type Lang } from '../data/creditsAndFaq';

interface CreditsSheetProps {
  open: boolean;
  onClose: () => void;
  lang: Lang;
}

function CreditCard({ item, lang }: { item: CreditEntry; lang: Lang }) {
  const isEn = lang === 'en';
  const role = isEn ? item.roleEn : item.roleTh;
  const bio = isEn ? item.bioEn : item.bioTh;

  const content = (
    <div className="group h-full overflow-hidden rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1a1522] shadow-xs hover:border-[#e5303f]/45 transition-colors flex flex-col">
      {/* Dedicated Cover Image per Credit */}
      <div
        className="relative h-36 sm:h-40 w-full overflow-hidden border-b border-slate-200/80 dark:border-white/10 flex items-center justify-center"
        style={item.coverBg ? { backgroundColor: item.coverBg } : undefined}
      >
        <img
          src={item.coverImage}
          alt={item.name}
          referrerPolicy="no-referrer"
          className={
            item.coverKind === 'logo'
              ? 'h-24 w-24 sm:h-28 sm:w-28 rounded-2xl object-contain transition-transform duration-300 group-hover:scale-105'
              : `w-full h-full object-cover ${item.objectPosition || 'object-center'} transition-transform duration-300 group-hover:scale-105`
          }
        />
        {item.coverKind === 'portrait' && (
          <div
            aria-hidden="true"
            className="absolute inset-x-0 bottom-0 h-14 bg-gradient-to-t from-black/45 to-transparent"
          />
        )}
      </div>

      {/* Body with overlapping circular avatar and clean unboxed metadata */}
      <div className="relative px-4 pb-4 pt-8 flex-1 flex flex-col">
        <div
          className="absolute -top-7 left-4 w-14 h-14 rounded-2xl border-2 border-white dark:border-[#1a1522] overflow-hidden shadow-md flex items-center justify-center"
          style={item.coverBg ? { backgroundColor: item.coverBg } : { backgroundColor: '#f8fafc' }}
        >
          <img
            src={item.coverImage}
            alt=""
            aria-hidden="true"
            referrerPolicy="no-referrer"
            className={
              item.coverKind === 'logo'
                ? 'w-full h-full object-contain p-1 rounded-xl'
                : `w-full h-full object-cover ${item.objectPosition || 'object-center'}`
            }
          />
        </div>

        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <h3 className="font-display text-base font-bold text-slate-900 dark:text-white truncate">
              {item.name}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 break-all">{item.subtitle}</p>
          </div>
          {item.email && (
            <Mail className="w-4 h-4 text-slate-400 group-hover:text-[#e5303f] shrink-0 mt-1 transition-colors" />
          )}
        </div>

        <p className="mt-2 text-xs font-semibold text-[#e5303f] dark:text-[#ff6b78]">{role}</p>
        <p className="mt-1.5 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">{bio}</p>
      </div>
    </div>
  );

  if (item.email) {
    return (
      <a
        href={`mailto:${item.email}`}
        className="block rounded-2xl focus-visible:outline-2 focus-visible:outline-[#e5303f]"
      >
        {content}
      </a>
    );
  }

  return <div>{content}</div>;
}

export function CreditsSheet({ open, onClose, lang }: CreditsSheetProps) {
  if (!open) return null;
  const isEn = lang === 'en';

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label={isEn ? 'Credits' : 'เครดิต'}
    >
      <div
        className="fixed inset-0 bg-black/55 backdrop-blur-xs"
        onClick={onClose}
        aria-hidden="true"
      />

      <div className="relative z-10 w-full max-w-3xl max-h-[88dvh] flex flex-col rounded-t-3xl sm:rounded-3xl border border-slate-200 dark:border-white/10 bg-[#faf8f9] dark:bg-[#120f17] shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-white/10 bg-white dark:bg-[#1a1522]">
          <div>
            <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
              {isEn ? 'Credits' : 'เครดิต'}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {isEn ? 'Creators & AI partners behind Opus Studio' : 'ผู้สร้าง ผู้ร่วมพัฒนา และผู้ช่วย AI'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={isEn ? 'Close' : 'ปิด'}
            className="min-h-[44px] min-w-[44px] inline-flex items-center justify-center rounded-xl bg-slate-100 dark:bg-white/10 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-white/20 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 sm:p-6 overflow-y-auto grid grid-cols-1 sm:grid-cols-2 gap-4">
          {CREDIT_ITEMS.map((item) => (
            <CreditCard key={item.id} item={item} lang={lang} />
          ))}
        </div>
      </div>
    </div>
  );
}
