import { Check, Copy, Download, ImagePlus, Music, Trash2, Upload } from 'lucide-react';
import { useEffect, useRef, useState, type ChangeEvent, type DragEvent } from 'react';
import type { Lang } from '../data/creditsAndFaq';
import {
  buildMp3File,
  buildOpusFile,
  detectAudioFormat,
  parseMp3File,
  parseOpusFile,
  sanitizeDownloadName,
  type CoverData,
  type ParsedAudioFile,
} from '../utils/audioTags';
import { normalizeSpotifyTrackUrl } from '../utils/mediaHelpers';
import type { PendingTagPayload } from './YoutubeInfoTab';

interface TagEditorTabProps {
  lang: Lang;
  pendingTags: PendingTagPayload | null;
  onConsumePendingTags: () => void;
}

async function convertBlobToJpegCover(blob: Blob): Promise<CoverData> {
  const bitmap = await createImageBitmap(blob);
  const scale = Math.min(1, 800 / Math.max(bitmap.width, bitmap.height));
  const width = Math.max(1, Math.round(bitmap.width * scale));
  const height = Math.max(1, Math.round(bitmap.height * scale));
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas unavailable');
  ctx.drawImage(bitmap, 0, 0, width, height);
  bitmap.close();
  const jpegBlob = await new Promise<Blob | null>((resolve) =>
    canvas.toBlob(resolve, 'image/jpeg', 0.9)
  );
  if (!jpegBlob) throw new Error('JPEG encode failed');
  return {
    bytes: new Uint8Array(await jpegBlob.arrayBuffer()),
    mime: 'image/jpeg',
    width,
    height,
  };
}

export function TagEditorTab({ lang, pendingTags, onConsumePendingTags }: TagEditorTabProps) {
  const isEn = lang === 'en';
  const [parsedFile, setParsedFile] = useState<ParsedAudioFile | null>(null);
  const [fileName, setFileName] = useState('');
  const [audioUrl, setAudioUrl] = useState('');
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');
  const [album, setAlbum] = useState('');
  const [coverData, setCoverData] = useState<CoverData | null | undefined>(undefined);
  const [coverPreviewUrl, setCoverPreviewUrl] = useState('');
  const [dragOver, setDragOver] = useState(false);
  const [statusMsg, setStatusMsg] = useState('');
  const [isError, setIsError] = useState(false);

  const [spotifyUrl, setSpotifyUrl] = useState('');
  const [spotifyLoading, setSpotifyLoading] = useState(false);
  const [spotifyResult, setSpotifyResult] = useState<{ title: string; artist: string } | null>(null);
  const [copiedSp, setCopiedSp] = useState<'artist' | 'title' | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    return () => {
      if (coverPreviewUrl) URL.revokeObjectURL(coverPreviewUrl);
    };
  }, [coverPreviewUrl]);

  useEffect(() => {
    return () => {
      if (audioUrl) URL.revokeObjectURL(audioUrl);
    };
  }, [audioUrl]);

  // Apply pending tags from YouTube Info tab immediately if a file is already loaded
  useEffect(() => {
    if (pendingTags && parsedFile) {
      setTitle(pendingTags.title);
      setArtist(pendingTags.artist);
      setStatusMsg(
        isEn ? 'Title and artist from the YouTube clip filled in.' : 'ใส่ชื่อเพลงและศิลปินจากคลิป YouTube แล้ว'
      );
      setIsError(false);
    }
  }, [pendingTags, parsedFile, isEn]);

  const updateCoverPreview = (bytes: Uint8Array | null, mime = 'image/jpeg') => {
    if (coverPreviewUrl) URL.revokeObjectURL(coverPreviewUrl);
    if (!bytes) {
      setCoverPreviewUrl('');
      return;
    }
    const copy = new Uint8Array(bytes);
    const url = URL.createObjectURL(new Blob([copy], { type: mime }));
    setCoverPreviewUrl(url);
  };

  const loadAudioFile = async (file: File) => {
    setIsError(false);
    setStatusMsg('');
    try {
      const buffer = new Uint8Array(await file.arrayBuffer());
      const format = detectAudioFormat(file.name, file.type, buffer);
      const parsed = format === 'mp3' ? parseMp3File(buffer) : parseOpusFile(buffer);

      setParsedFile(parsed);
      setFileName(file.name);

      if (audioUrl) URL.revokeObjectURL(audioUrl);
      setAudioUrl(URL.createObjectURL(file));

      if (pendingTags) {
        setTitle(pendingTags.title);
        setArtist(pendingTags.artist);
        onConsumePendingTags();
      } else {
        setTitle(parsed.tags.title);
        setArtist(parsed.tags.artist);
      }
      setAlbum(parsed.tags.album);

      if (parsed.cover) {
        setCoverData(parsed.cover);
        updateCoverPreview(parsed.cover.bytes, parsed.cover.mime);
      } else {
        setCoverData(undefined);
        updateCoverPreview(null);
      }
    } catch (err) {
      setParsedFile(null);
      setFileName('');
      updateCoverPreview(null);
      setIsError(true);
      const message = err instanceof Error ? err.message : 'Unknown error';
      setStatusMsg(isEn ? `Error: ${message}` : `ผิดพลาด: ${message}`);
    }
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (file) void loadAudioFile(file);
  };

  const handleDrop = (e: DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) void loadAudioFile(file);
  };

  const handleCoverPick = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    try {
      const converted = await convertBlobToJpegCover(file);
      setCoverData(converted);
      updateCoverPreview(converted.bytes, 'image/jpeg');
      setStatusMsg('');
      setIsError(false);
    } catch {
      setIsError(true);
      setStatusMsg(isEn ? 'Could not read the image.' : 'อ่านรูปไม่ได้');
    }
  };

  const handleRemoveCover = () => {
    setCoverData(null);
    updateCoverPreview(null);
  };

  const handleUseYoutubeThumb = async () => {
    if (!pendingTags?.thumbnailUrl) return;
    setIsError(false);
    setStatusMsg(isEn ? 'Fetching YouTube thumbnail...' : 'กำลังดึงภาพปกคลิป...');
    try {
      const res = await fetch(`/api/image-proxy?url=${encodeURIComponent(pendingTags.thumbnailUrl)}`);
      if (!res.ok) throw new Error('Fetch failed');
      const blob = await res.blob();
      const converted = await convertBlobToJpegCover(blob);
      setCoverData(converted);
      updateCoverPreview(converted.bytes, 'image/jpeg');
      setStatusMsg(isEn ? 'YouTube thumbnail applied as cover.' : 'นำภาพปกคลิปมาใช้เป็นปกเพลงแล้ว');
      onConsumePendingTags();
    } catch {
      setIsError(true);
      setStatusMsg(isEn ? 'Could not load YouTube thumbnail.' : 'ไม่สามารถดึงภาพปกคลิปได้');
    }
  };

  const handleSpotifyLookup = async () => {
    const normalized = normalizeSpotifyTrackUrl(spotifyUrl);
    if (!normalized) {
      setIsError(true);
      setStatusMsg(
        isEn
          ? 'The link must be a Spotify track link (…/track/…)'
          : 'ลิงก์ต้องเป็นลิงก์เพลงของ Spotify (…/track/…)'
      );
      return;
    }

    setSpotifyLoading(true);
    setSpotifyResult(null);
    setIsError(false);
    setStatusMsg(isEn ? 'Fetching from Spotify...' : 'กำลังดึงข้อมูลจาก Spotify...');

    try {
      let data: { title?: string; artist?: string; thumbnailUrl?: string } | null = null;
      if (window.location.protocol !== 'file:') {
        try {
          const res = await fetch(`/api/spotify-info?url=${encodeURIComponent(normalized)}`);
          if (res.ok && (res.headers.get('content-type') || '').includes('application/json')) {
            data = (await res.json()) as { title?: string; artist?: string; thumbnailUrl?: string };
          }
        } catch {
          // Fallback below
        }
      }

      if (!data) {
        let spTitle = '';
        let spThumb = '';
        let spArtist = '';
        try {
          const oe = await fetch(`https://open.spotify.com/oembed?url=${encodeURIComponent(normalized)}`);
          if (oe.ok) {
            const j = (await oe.json()) as { title?: string; thumbnail_url?: string };
            spTitle = j.title || '';
            spThumb = j.thumbnail_url || '';
          }
        } catch {
          // ignore
        }
        for (const relay of [
          `https://api.allorigins.win/raw?url=${encodeURIComponent(normalized)}`,
          `https://corsproxy.io/?url=${encodeURIComponent(normalized)}`,
        ]) {
          try {
            const html = await (await fetch(relay)).text();
            const m =
              html.match(/<meta[^>]+property=["']music:musician_description["'][^>]+content=["']([^"']*)["']/i) ||
              html.match(/<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']*)["']/i);
            if (m?.[1]) {
              spArtist = m[1].split(' · ')[0].trim();
              break;
            }
          } catch {
            // ignore
          }
        }
        if (spTitle || spArtist) {
          data = { title: spTitle, artist: spArtist, thumbnailUrl: spThumb };
        }
      }

      if (!data) throw new Error('Spotify lookup failed');

      if (data.title) setTitle(data.title);
      if (data.thumbnailUrl) {
        try {
          const imgUrl =
            window.location.protocol !== 'file:'
              ? `/api/image-proxy?url=${encodeURIComponent(data.thumbnailUrl)}`
              : data.thumbnailUrl;
          let imgRes = await fetch(imgUrl);
          if (!imgRes.ok && imgUrl !== data.thumbnailUrl) {
            imgRes = await fetch(data.thumbnailUrl);
          }
          if (imgRes.ok) {
            const converted = await convertBlobToJpegCover(await imgRes.blob());
            setCoverData(converted);
            updateCoverPreview(converted.bytes, 'image/jpeg');
          }
        } catch {
          // Non-fatal if cover proxy fails
        }
      }

      if (data.title || data.artist) {
        setSpotifyResult({ title: data.title || '', artist: data.artist || '' });
        setStatusMsg(
          data.artist
            ? isEn
              ? 'Fetched metadata and cover from Spotify.'
              : 'ดึงข้อมูลและปกเพลงจาก Spotify แล้ว'
            : isEn
              ? 'Got cover and title, but artist could not be extracted.'
              : 'ดึงปกและชื่อเพลงแล้ว แต่หาชื่อศิลปินไม่เจอ สามารถพิมพ์เพิ่มเองได้'
        );
      } else {
        throw new Error('No metadata');
      }
    } catch {
      setIsError(true);
      setStatusMsg(
        isEn
          ? 'Could not fetch from Spotify. You can still choose a cover image from your device.'
          : 'ดึงจาก Spotify ไม่ได้ คุณสามารถบันทึกรูปปกลงเครื่องแล้วกด "เลือกรูปปก" แทนได้'
      );
    } finally {
      setSpotifyLoading(false);
    }
  };

  const copySpotifyText = async (text: string, which: 'artist' | 'title') => {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    }
    setCopiedSp(which);
    window.setTimeout(() => setCopiedSp((c) => (c === which ? null : c)), 1500);
  };

  const handleSaveAndDownload = () => {
    if (!parsedFile) return;
    try {
      const tagValues = { title, artist, album };
      const outBytes =
        parsedFile.format === 'mp3'
          ? buildMp3File(parsedFile, tagValues, coverData)
          : buildOpusFile(parsedFile, tagValues, coverData);

      const mime = parsedFile.format === 'mp3' ? 'audio/mpeg' : 'audio/ogg';
      const safeBytes = new Uint8Array(outBytes);
      const blob = new Blob([safeBytes], { type: mime });
      const dlName = sanitizeDownloadName(title, fileName, parsedFile.format);

      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = dlName;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 5000);

      const sizeMb = (blob.size / 1048576).toFixed(2);
      setIsError(false);
      setStatusMsg(isEn ? `Saved • ${sizeMb} MB` : `บันทึกแล้ว • ${sizeMb} MB`);
    } catch (err) {
      setIsError(true);
      const message = err instanceof Error ? err.message : 'Save error';
      setStatusMsg(isEn ? `Error: ${message}` : `ผิดพลาด: ${message}`);
    }
  };

  return (
    <div className="space-y-4">
      {/* Pending banner when user came from YouTube Info */}
      {pendingTags && (
        <div className="rounded-2xl border border-orange-200 dark:border-orange-500/30 bg-orange-50 dark:bg-orange-500/10 p-4 flex flex-wrap items-center justify-between gap-3">
          <div className="text-sm text-orange-900 dark:text-orange-100">
            <p className="font-semibold">
              {isEn ? 'Ready from YouTube Info:' : 'เตรียมข้อมูลจาก YouTube ไว้แล้ว:'}{' '}
              <span className="font-normal">
                {pendingTags.artist ? `${pendingTags.artist} — ` : ''}
                {pendingTags.title}
              </span>
            </p>
            <p className="text-xs text-orange-700 dark:text-orange-200/80 mt-0.5">
              {parsedFile
                ? isEn
                  ? 'Fields updated. You can also import the clip thumbnail below.'
                  : 'เติมชื่อเพลงและศิลปินให้แล้ว และสามารถดึงภาพปกคลิปมาใช้ได้'
                : isEn
                  ? 'Select an .opus, .ogg, or .mp3 file below to fill these tags automatically.'
                  : 'เลือกไฟล์ .opus, .ogg หรือ .mp3 ด้านล่างเพื่อเติมแท็กอัตโนมัติ'}
            </p>
          </div>
          {parsedFile && pendingTags.thumbnailUrl && (
            <button
              type="button"
              onClick={() => void handleUseYoutubeThumb()}
              className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-orange-600 text-white text-xs font-semibold hover:bg-orange-700 transition-colors"
            >
              {isEn ? 'Use YouTube thumbnail' : 'ใช้ภาพปกคลิป'}
            </button>
          )}
        </div>
      )}

      {/* Dropzone Card */}
      <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1a1522] p-5 sm:p-6 shadow-xs">
        <label
          onDragEnter={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={(e) => {
            e.preventDefault();
            setDragOver(false);
          }}
          onDrop={handleDrop}
          className={`block text-center border-2 border-dashed rounded-2xl p-6 sm:p-8 cursor-pointer transition-colors ${
            dragOver
              ? 'border-[#e5303f] bg-[#e5303f]/5'
              : 'border-slate-300 dark:border-white/15 bg-slate-50/70 dark:bg-white/[0.02] hover:border-[#e5303f]/60'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".opus,.ogg,.mp3,audio/ogg,audio/mpeg"
            onChange={handleFileChange}
            className="hidden"
          />
          <Upload className="w-7 h-7 mx-auto mb-2.5 text-[#e5303f] dark:text-[#ff6b78]" />
          <span className="block font-display text-base font-semibold text-slate-900 dark:text-white">
            {isEn
              ? 'Drop an .opus, .ogg, or .mp3 file here, or tap to choose'
              : 'ลากไฟล์ .opus, .ogg หรือ .mp3 มาวาง หรือแตะเพื่อเลือก'}
          </span>
          <span className="block mt-1 text-sm text-slate-500 dark:text-slate-400 break-all">
            {fileName ||
              (isEn ? 'Edit title, artist, album, and cover art' : 'แก้ชื่อเพลง ศิลปิน อัลบั้ม และปกเพลง')}
          </span>
        </label>

        {parsedFile && audioUrl && (
          <div className="mt-4 pt-4 border-t border-slate-200 dark:border-white/10 flex flex-col sm:flex-row sm:items-center gap-3">
            <span className="text-xs font-semibold uppercase tracking-wide text-[#e5303f] dark:text-[#ff6b78] shrink-0">
              {parsedFile.format.toUpperCase()} {isEn ? 'Preview' : 'ฟังตัวอย่าง'}
            </span>
            <audio controls src={audioUrl} className="w-full h-10" />
          </div>
        )}
      </div>

      {/* Editor Form */}
      {parsedFile && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left: Metadata & Cover */}
          <div className="lg:col-span-7 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1a1522] p-5 sm:p-6 shadow-xs space-y-4">
            {/* Title */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label htmlFor="t-title" className="text-sm font-medium text-slate-600 dark:text-slate-300">
                  {isEn ? 'Title' : 'ชื่อเพลง'}
                </label>
                {title.trim().length > 0 && (
                  <button
                    type="button"
                    onClick={() => setTitle('')}
                    className="px-2.5 py-0.5 rounded-md border border-[#e5303f]/30 bg-[#e5303f]/10 text-[#e5303f] dark:text-[#ff6b78] text-xs font-semibold hover:bg-[#e5303f] hover:text-white transition-colors"
                  >
                    {isEn ? 'Clear' : 'ล้าง'}
                  </button>
                )}
              </div>
              <input
                id="t-title"
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-[#120f17] text-slate-900 dark:text-white text-sm sm:text-base focus:outline-none focus:border-[#e5303f]"
              />
            </div>

            {/* Artist */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label htmlFor="t-artist" className="text-sm font-medium text-slate-600 dark:text-slate-300">
                  {isEn ? 'Artist' : 'ศิลปิน'}
                </label>
                {artist.trim().length > 0 && (
                  <button
                    type="button"
                    onClick={() => setArtist('')}
                    className="px-2.5 py-0.5 rounded-md border border-[#e5303f]/30 bg-[#e5303f]/10 text-[#e5303f] dark:text-[#ff6b78] text-xs font-semibold hover:bg-[#e5303f] hover:text-white transition-colors"
                  >
                    {isEn ? 'Clear' : 'ล้าง'}
                  </button>
                )}
              </div>
              <input
                id="t-artist"
                type="text"
                value={artist}
                onChange={(e) => setArtist(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-[#120f17] text-slate-900 dark:text-white text-sm sm:text-base focus:outline-none focus:border-[#e5303f]"
              />
            </div>

            {/* Album */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label htmlFor="t-album" className="text-sm font-medium text-slate-600 dark:text-slate-300">
                  {isEn ? 'Album' : 'อัลบั้ม'}
                </label>
                {album.trim().length > 0 && (
                  <button
                    type="button"
                    onClick={() => setAlbum('')}
                    className="px-2.5 py-0.5 rounded-md border border-[#e5303f]/30 bg-[#e5303f]/10 text-[#e5303f] dark:text-[#ff6b78] text-xs font-semibold hover:bg-[#e5303f] hover:text-white transition-colors"
                  >
                    {isEn ? 'Clear' : 'ล้าง'}
                  </button>
                )}
              </div>
              <input
                id="t-album"
                type="text"
                value={album}
                onChange={(e) => setAlbum(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-[#120f17] text-slate-900 dark:text-white text-sm sm:text-base focus:outline-none focus:border-[#e5303f]"
              />
            </div>

            {/* Cover Art */}
            <div className="pt-2 flex items-center gap-4">
              <div className="relative w-28 h-28 rounded-2xl border border-slate-200 dark:border-white/15 bg-slate-100 dark:bg-[#120f17] overflow-hidden shrink-0 grid place-items-center text-slate-400">
                {coverPreviewUrl ? (
                  <img
                    src={coverPreviewUrl}
                    alt={isEn ? 'Cover art' : 'ปกเพลง'}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <Music className="w-8 h-8" />
                )}
              </div>

              <div className="flex-1 flex flex-col gap-2">
                <label className="min-h-[42px] px-4 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 text-slate-800 dark:text-slate-100 text-sm font-medium text-center cursor-pointer hover:border-[#e5303f]/60 inline-flex items-center justify-center gap-2 transition-colors">
                  <ImagePlus className="w-4 h-4" />
                  <span>{isEn ? 'Choose cover' : 'เลือกรูปปก'}</span>
                  <input type="file" accept="image/*" onChange={handleCoverPick} className="hidden" />
                </label>

                <button
                  type="button"
                  onClick={handleRemoveCover}
                  className="min-h-[42px] px-4 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 text-slate-700 dark:text-slate-300 text-sm font-medium hover:border-[#e5303f]/60 inline-flex items-center justify-center gap-2 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>{isEn ? 'Remove cover' : 'ลบปก'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Right: Optional Spotify & Save */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1a1522] p-5 shadow-xs space-y-3">
              <label htmlFor="t-spurl" className="block text-sm font-medium text-slate-600 dark:text-slate-300">
                {isEn
                  ? 'Fetch cover, title & artist from Spotify link (optional)'
                  : 'ดึงปก ชื่อเพลง และชื่อศิลปินจากลิงก์ Spotify (ไม่บังคับ)'}
              </label>

              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  id="t-spurl"
                  type="text"
                  value={spotifyUrl}
                  onChange={(e) => setSpotifyUrl(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') void handleSpotifyLookup();
                  }}
                  placeholder="https://open.spotify.com/track/..."
                  className="flex-1 min-w-0 px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-[#120f17] text-sm text-slate-900 dark:text-white focus:outline-none focus:border-[#e5303f]"
                />
                <div className="flex gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      setSpotifyUrl('');
                      setSpotifyResult(null);
                      setStatusMsg('');
                    }}
                    className="min-h-[42px] px-3 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 text-xs font-medium text-slate-700 dark:text-slate-200"
                  >
                    {isEn ? 'Clear' : 'ล้าง'}
                  </button>
                  <button
                    type="button"
                    onClick={() => void handleSpotifyLookup()}
                    disabled={spotifyLoading}
                    className="min-h-[42px] px-4 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-semibold disabled:opacity-60"
                  >
                    {spotifyLoading ? '...' : isEn ? 'Fetch' : 'ดึง'}
                  </button>
                </div>
              </div>

              {spotifyResult && (
                <div className="p-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#120f17] space-y-3">
                  {spotifyResult.artist && (
                    <div>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {isEn ? 'Artist on Spotify' : 'ชื่อศิลปินใน Spotify'}
                      </p>
                      <p className="text-sm font-semibold text-slate-900 dark:text-white mt-0.5">
                        {spotifyResult.artist}
                      </p>
                      <button
                        type="button"
                        onClick={() => void copySpotifyText(spotifyResult.artist, 'artist')}
                        className="mt-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-white/15 bg-white dark:bg-white/5 text-xs font-medium inline-flex items-center gap-1.5"
                      >
                        {copiedSp === 'artist' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>
                          {copiedSp === 'artist'
                            ? isEn
                              ? 'Copied ✓'
                              : 'คัดลอกแล้ว ✓'
                            : isEn
                              ? 'Copy artist name'
                              : 'คัดลอกชื่อศิลปิน'}
                        </span>
                      </button>
                    </div>
                  )}

                  {spotifyResult.title && (
                    <div>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {isEn ? 'Title on Spotify' : 'ชื่อเพลงใน Spotify'}
                      </p>
                      <p className="text-sm font-semibold text-slate-900 dark:text-white mt-0.5">
                        {spotifyResult.title}
                      </p>
                      <button
                        type="button"
                        onClick={() => void copySpotifyText(spotifyResult.title, 'title')}
                        className="mt-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-white/15 bg-white dark:bg-white/5 text-xs font-medium inline-flex items-center gap-1.5"
                      >
                        {copiedSp === 'title' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>
                          {copiedSp === 'title'
                            ? isEn
                              ? 'Copied ✓'
                              : 'คัดลอกแล้ว ✓'
                            : isEn
                              ? 'Copy title'
                              : 'คัดลอกชื่อเพลง'}
                        </span>
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1a1522] p-5 shadow-xs">
              <button
                type="button"
                onClick={handleSaveAndDownload}
                className="w-full min-h-[50px] px-5 py-3 rounded-xl bg-gradient-to-r from-[#e5303f] to-[#ff7a45] text-white font-display font-semibold text-base shadow-md shadow-[#e5303f]/25 hover:shadow-lg inline-flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
              >
                <Download className="w-5 h-5" />
                <span>{isEn ? 'Save tags and download' : 'บันทึกแท็กและดาวน์โหลด'}</span>
              </button>

              {statusMsg && (
                <p
                  role={isError ? 'alert' : 'status'}
                  className={`mt-3 text-sm tabular-nums ${
                    isError ? 'text-[#e5303f] dark:text-[#ff6b78] font-medium' : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {statusMsg}
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {!parsedFile && statusMsg && (
        <p
          role={isError ? 'alert' : 'status'}
          className={`text-sm px-1 ${
            isError ? 'text-[#e5303f] dark:text-[#ff6b78] font-medium' : 'text-slate-600 dark:text-slate-300'
          }`}
        >
          {statusMsg}
        </p>
      )}
    </div>
  );
}
