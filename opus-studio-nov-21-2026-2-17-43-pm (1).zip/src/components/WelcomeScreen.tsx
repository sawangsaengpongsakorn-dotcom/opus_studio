import { ArrowRight, PlayCircle, Sparkles } from 'lucide-react';
import { WELCOME_FEATURES, type Lang } from '../data/creditsAndFaq';

interface WelcomeScreenProps {
  lang: Lang;
  onStart: () => void;
  onOpenYoutube: () => void;
  onOpenCredits: () => void;
}

export function WelcomeScreen({
  lang,
  onStart,
  onOpenYoutube,
  onOpenCredits,
}: WelcomeScreenProps) {
  const isEn = lang === 'en';

  return (
    <section className="max-w-5xl mx-auto px-4 sm:px-6 pt-10 pb-16 sm:pt-14 sm:pb-24">
      {/* Hero block */}
      <div className="relative overflow-hidden rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1a1522] p-6 sm:p-10 md:p-12 shadow-sm">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -top-24 -right-24 w-72 h-72 rounded-full bg-gradient-to-br from-[#e5303f]/15 to-[#ff7a45]/10 blur-2xl"
        />

        <div className="relative max-w-3xl">
          <p className="text-sm font-semibold text-[#e5303f] dark:text-[#ff6b78] mb-3">
            {isEn ? 'Opus Studio · Audio Metadata & Clip Info' : 'Opus Studio · เครื่องมือจัดการแท็กเพลงและข้อมูลคลิป'}
          </p>

          <h1 className="font-display text-3xl sm:text-5xl font-bold tracking-tight text-slate-900 dark:text-white leading-tight [text-wrap:balance]">
            {isEn
              ? 'Edit Opus & MP3 tags and look up YouTube clips in one place'
              : 'แท็กเพลงและดึงข้อมูลคลิป YouTube ครบจบในที่เดียว'}
          </h1>

          <p className="mt-4 text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl">
            {isEn
              ? 'Update song titles, artists, albums, and cover artwork right in your browser, or extract clip details from YouTube and Spotify effortlessly.'
              : 'แก้ไขชื่อเพลง ชื่อศิลปิน อัลบั้ม และภาพปกสำหรับไฟล์ .opus, .ogg และ .mp3 ได้ทันทีบนเบราว์เซอร์ พร้อมดึงข้อมูลจาก YouTube และ Spotify อย่างรวดเร็ว'}
          </p>

          {/* Primary CTA: เริ่มต้นใช้งาน */}
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={onStart}
              className="min-h-[48px] px-7 py-3 rounded-2xl bg-gradient-to-r from-[#e5303f] to-[#ff7a45] text-white font-display font-semibold text-base shadow-md shadow-[#e5303f]/25 hover:shadow-lg hover:shadow-[#e5303f]/35 active:scale-[0.98] transition-all inline-flex items-center gap-2.5 whitespace-nowrap"
            >
              <span>{isEn ? 'Get Started' : 'เริ่มต้นใช้งาน'}</span>
              <ArrowRight className="w-5 h-5" />
            </button>

            <button
              type="button"
              onClick={onOpenYoutube}
              className="min-h-[48px] px-5 py-3 rounded-2xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 text-slate-800 dark:text-slate-100 font-medium text-sm sm:text-base hover:border-[#e5303f]/50 transition-colors inline-flex items-center gap-2 whitespace-nowrap"
            >
              <PlayCircle className="w-4 h-4 text-[#e5303f] dark:text-[#ff6b78]" />
              <span>{isEn ? 'YouTube Info' : 'ดูข้อมูล YouTube'}</span>
            </button>
          </div>
        </div>

        {/* Website descriptions directly below เริ่มต้นใช้งาน */}
        <div className="relative mt-10 pt-8 border-t border-slate-200/80 dark:border-white/10">
          <div className="flex flex-wrap items-baseline justify-between gap-2 mb-6">
            <h2 className="font-display text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
              {isEn ? 'Why use Opus Studio' : 'เกี่ยวกับเว็บ Opus Studio'}
            </h2>
            <span className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
              {isEn ? 'No installation · Works on desktop and mobile' : 'ไม่ต้องติดตั้งโปรแกรม · ใช้งานได้ทั้งคอมพิวเตอร์และมือถือ'}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
            {WELCOME_FEATURES.map((item) => (
              <div
                key={item.num}
                className="p-5 rounded-2xl border border-slate-200/90 dark:border-white/10 bg-slate-50/70 dark:bg-white/[0.03] flex items-start gap-4"
              >
                <span className="font-display text-sm font-bold text-[#e5303f] dark:text-[#ff6b78] tabular-nums pt-0.5 shrink-0">
                  {item.num}.
                </span>
                <div>
                  <h3 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                    {isEn ? item.titleEn : item.titleTh}
                  </h3>
                  <p className="mt-1 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                    {isEn ? item.descEn : item.descTh}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-7 flex flex-wrap items-center justify-between gap-4 pt-5 border-t border-slate-200/70 dark:border-white/10 text-sm text-slate-500 dark:text-slate-400">
            <span>
              {isEn
                ? 'Supports .opus, .ogg, .mp3 and cover images (JPG / PNG / WebP)'
                : 'รองรับไฟล์เสียง .opus, .ogg, .mp3 และรูปปกเพลงทั่วไป'}
            </span>
            <button
              type="button"
              onClick={onOpenCredits}
              className="inline-flex items-center gap-1.5 font-semibold text-[#e5303f] dark:text-[#ff6b78] hover:underline py-1"
            >
              <Sparkles className="w-4 h-4" />
              <span>{isEn ? 'View Credits & Creators' : 'ดูเครดิตผู้สร้างและทีมพัฒนา'}</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
