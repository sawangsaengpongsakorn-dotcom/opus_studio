import { Send, X } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { FAQ_EN, FAQ_TH, matchFaqReply, type Lang } from '../data/creditsAndFaq';

interface FaqSheetProps {
  open: boolean;
  onClose: () => void;
  lang: Lang;
}

interface ChatMessage {
  id: number;
  sender: 'me' | 'bot';
  text: string;
}

export function FaqSheet({ open, onClose, lang }: FaqSheetProps) {
  const isEn = lang === 'en';
  const faqList = isEn ? FAQ_EN : FAQ_TH;

  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      id: 1,
      sender: 'bot',
      text: isEn
        ? 'Hi! Pick a question below or type your own. I reply automatically.'
        : 'สวัสดีครับ เลือกคำถามด้านล่าง หรือพิมพ์ถามได้เลย ผมตอบอัตโนมัติครับ',
    },
  ]);
  const [usedChips, setUsedChips] = useState<Set<number>>(() => new Set());
  const [input, setInput] = useState('');
  const bodyRef = useRef<HTMLDivElement>(null);
  const nextId = useRef(2);

  useEffect(() => {
    setMessages([
      {
        id: nextId.current++,
        sender: 'bot',
        text: isEn
          ? 'Hi! Pick a question below or type your own. I reply automatically.'
          : 'สวัสดีครับ เลือกคำถามด้านล่าง หรือพิมพ์ถามได้เลย ผมตอบอัตโนมัติครับ',
      },
    ]);
    setUsedChips(new Set());
  }, [isEn]);

  useEffect(() => {
    if (bodyRef.current) {
      bodyRef.current.scrollTop = bodyRef.current.scrollHeight;
    }
  }, [messages, open]);

  if (!open) return null;

  const pushQuestion = (question: string, answer: string, chipIndex?: number) => {
    const qId = nextId.current++;
    const aId = nextId.current++;
    if (chipIndex !== undefined) {
      setUsedChips((prev) => new Set(prev).add(chipIndex));
    }
    setMessages((prev) => [
      ...prev,
      { id: qId, sender: 'me', text: question },
      { id: aId, sender: 'bot', text: answer },
    ]);
  };

  const handleSend = () => {
    const trimmed = input.trim();
    if (!trimmed) return;
    setInput('');
    pushQuestion(trimmed, matchFaqReply(trimmed, lang));
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label={isEn ? 'FAQ' : 'คำถามที่พบบ่อย'}
    >
      <div
        className="fixed inset-0 bg-black/55 backdrop-blur-xs"
        onClick={onClose}
        aria-hidden="true"
      />

      <div className="relative z-10 w-full max-w-xl max-h-[88dvh] flex flex-col rounded-t-3xl sm:rounded-3xl border border-slate-200 dark:border-white/10 bg-[#faf8f9] dark:bg-[#120f17] shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-white/10 bg-white dark:bg-[#1a1522]">
          <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
            {isEn ? 'Auto Q&A' : 'ถาม-ตอบอัตโนมัติ'}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label={isEn ? 'Close' : 'ปิด'}
            className="min-h-[44px] min-w-[44px] inline-flex items-center justify-center rounded-xl bg-slate-100 dark:bg-white/10 text-slate-700 dark:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div ref={bodyRef} className="flex-1 min-h-0 overflow-y-auto p-4 flex flex-col gap-2.5">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`max-w-[86%] px-3.5 py-2.5 rounded-2xl text-sm whitespace-pre-line leading-relaxed ${
                m.sender === 'me'
                  ? 'self-end bg-gradient-to-r from-[#e5303f] to-[#ff7a45] text-white rounded-br-xs'
                  : 'self-start bg-white dark:bg-[#1a1522] border border-slate-200 dark:border-white/10 text-slate-800 dark:text-slate-100 rounded-bl-xs'
              }`}
            >
              {m.text}
            </div>
          ))}
        </div>

        <div className="px-4 py-3 border-t border-slate-200 dark:border-white/10 bg-white dark:bg-[#1a1522] flex flex-col gap-3">
          <div className="flex flex-wrap gap-1.5">
            {faqList.map((item, idx) => (
              <button
                key={item.q}
                type="button"
                onClick={() => pushQuestion(item.q, item.a, idx)}
                className={`px-3 py-1.5 rounded-xl border text-xs font-medium transition-colors ${
                  usedChips.has(idx)
                    ? 'border-slate-200 dark:border-white/10 text-slate-400 dark:text-slate-500 bg-slate-50 dark:bg-white/[0.02]'
                    : 'border-slate-200 dark:border-white/15 text-slate-700 dark:text-slate-200 bg-slate-50 dark:bg-white/5 hover:border-[#e5303f]/50'
                }`}
              >
                {item.q}
              </button>
            ))}
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSend();
              }}
              placeholder={isEn ? 'Type your question...' : 'พิมพ์คำถามของคุณ...'}
              className="flex-1 min-w-0 px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-[#120f17] text-sm text-slate-900 dark:text-white focus:outline-none focus:border-[#e5303f]"
            />
            <button
              type="button"
              onClick={handleSend}
              className="min-h-[44px] px-4 rounded-xl bg-gradient-to-r from-[#e5303f] to-[#ff7a45] text-white text-sm font-semibold inline-flex items-center gap-1.5 shrink-0"
            >
              <Send className="w-4 h-4" />
              <span>{isEn ? 'Send' : 'ส่ง'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
