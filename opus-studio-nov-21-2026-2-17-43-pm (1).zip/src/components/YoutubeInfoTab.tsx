import { ArrowRight, Check, Copy, Search, Trash2 } from 'lucide-react';
import { useRef, useState } from 'react';
import type { Lang } from '../data/creditsAndFaq';
import { normalizeYoutubeUrl, parseYoutubeClipToTags } from '../utils/mediaHelpers';

export interface YoutubeClipResult {
  title: string;
  channel: string;
  videoId: string;
  thumbnailUrl: string;
}

export interface PendingTagPayload {
  title: string;
  artist: string;
  thumbnailUrl?: string;
}

interface YoutubeInfoTabProps {
  lang: Lang;
  onUseInTagEditor: (payload: PendingTagPayload) => void;
}

export function YoutubeInfoTab({ lang, onUseInTagEditor }: YoutubeInfoTabProps) {
  const isEn = lang === 'en';
  const [urlInput, setUrlInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [clipInfo, setClipInfo] = useState<YoutubeClipResult | null>(null);
  const [thumbFailed, setThumbFailed] = useState(false);
  const [copiedKey, setCopiedKey] = useState<'title' | 'channel' | 'both' | 'apply' | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const flashCopied = (key: 'title' | 'channel' | 'both' | 'apply') => {
    setCopiedKey(key);
    window.setTimeout(() => {
      setCopiedKey((curr) => (curr === key ? null : curr));
    }, 1500);
  };

  const copyText = async (text: string, key: 'title' | 'channel' | 'both') => {
    let ok = false;
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
        ok = true;
      }
    } catch {
      ok = false;
    }
    if (!ok) {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.style.position = 'fixed';
      ta.style.left = '-9999px';
      document.body.appendChild(ta);
      ta.select();
      try {
        ok = document.execCommand('copy');
      } catch {
        ok = false;
      }
      ta.remove();
    }
    if (ok) {
      flashCopied(key);
    } else {
      setErrorMsg(isEn ? 'Could not copy. Try selecting the text manually.' : 'คัดลอกไม่ได้ ลองกดค้างที่ข้อความ');
    }
  };

  const handleLookup = async () => {
    setErrorMsg('');
    const normalized = normalizeYoutubeUrl(urlInput);
    if (!normalized) {
      setClipInfo(null);
      setErrorMsg(
        isEn
          ? 'Please enter a valid YouTube URL (youtube.com or youtu.be).'
          : 'กรุณาวางลิงก์ YouTube ที่ถูกต้อง (เช่น https://www.youtube.com/watch?v=...)'
      );
      return;
    }

    setLoading(true);
    setThumbFailed(false);
    try {
      let result: YoutubeClipResult | null = null;
      if (window.location.protocol !== 'file:') {
        try {
          const res = await fetch(`/api/youtube-info?url=${encodeURIComponent(normalized)}`);
          if (res.ok) {
            const ct = res.headers.get('content-type') || '';
            if (ct.includes('application/json')) {
              const data = (await res.json()) as YoutubeClipResult;
              if (data.title) result = data;
            }
          }
        } catch {
          // Fall through to public oEmbed endpoints
        }
      }

      if (!result) {
        const videoId =
          normalized.match(/(?:youtu\.be\/|v=|shorts\/|embed\/|live\/)([\w-]{11})/)?.[1] || '';
        const endpoints = [
          `https://www.youtube.com/oembed?format=json&url=${encodeURIComponent(normalized)}`,
          `https://noembed.com/embed?url=${encodeURIComponent(normalized)}`,
        ];
        for (const ep of endpoints) {
          try {
            const r = await fetch(ep);
            if (!r.ok) continue;
            const d = (await r.json()) as { title?: string; author_name?: string; thumbnail_url?: string };
            if (d?.title) {
              result = {
                title: d.title,
                channel: d.author_name || '',
                videoId,
                thumbnailUrl: videoId
                  ? `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`
                  : d.thumbnail_url || '',
              };
              break;
            }
          } catch {
            // Try next fallback
          }
        }
      }

      if (!result) {
        throw new Error('Empty result');
      }
      setClipInfo(result);
    } catch {
      setClipInfo(null);
      setErrorMsg(
        isEn
          ? 'Could not fetch clip details. Check the link, or the video may be private.'
          : 'ดึงข้อมูลไม่สำเร็จ ลองตรวจลิงก์ หรือคลิปอาจตั้งเป็นส่วนตัว'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleClear = () => {
    setUrlInput('');
    setErrorMsg('');
    setClipInfo(null);
    setThumbFailed(false);
    inputRef.current?.focus();
  };

  const handleApplyToTag = () => {
    if (!clipInfo) return;
    const parsed = parseYoutubeClipToTags(clipInfo.title, clipInfo.channel);
    flashCopied('apply');
    onUseInTagEditor({
      title: parsed.title,
      artist: parsed.artist,
      thumbnailUrl: !thumbFailed && clipInfo.thumbnailUrl ? clipInfo.thumbnailUrl : undefined,
    });
  };

  const copyBtnClass = (active: boolean) =>
    `min-h-[40px] px-4 py-2 rounded-xl border text-sm font-medium inline-flex items-center justify-center gap-2 transition-all active:scale-[0.97] ${
      active
        ? 'bg-gradient-to-r from-[#f97316] to-[#ea580c] border-[#f97316] text-white shadow-md shadow-orange-500/30'
        : 'bg-slate-50 dark:bg-white/5 border-slate-200 dark:border-white/15 text-slate-800 dark:text-slate-100 hover:border-[#e5303f]/60'
    }`;

  return (
    <div className="space-y-4">
      <div className="relative overflow-hidden rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1a1522] p-5 sm:p-6 shadow-xs">
        {loading && (
          <div
            aria-hidden="true"
            className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#e5303f] via-[#ff7a45] to-[#e5303f] animate-pulse"
          />
        )}

        <label
          htmlFor="y-url"
          className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-2"
        >
          {isEn ? 'YouTube Link' : 'ลิงก์ YouTube'}
        </label>

        <div className="flex flex-col sm:flex-row gap-2.5">
          <input
            ref={inputRef}
            id="y-url"
            type="url"
            inputMode="url"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleLookup();
            }}
            placeholder="https://www.youtube.com/watch?v=..."
            className="flex-1 min-w-0 px-4 py-3 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-[#120f17] text-slate-900 dark:text-white text-sm sm:text-base focus:outline-none focus:border-[#e5303f]"
          />
          <button
            type="button"
            onClick={handleClear}
            className="min-h-[44px] px-4 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-white/5 text-slate-700 dark:text-slate-200 text-sm font-medium hover:border-[#e5303f]/50 inline-flex items-center justify-center gap-1.5 shrink-0"
          >
            <Trash2 className="w-4 h-4" />
            <span>{isEn ? 'Clear' : 'ล้าง'}</span>
          </button>
        </div>

        <button
          type="button"
          onClick={handleLookup}
          disabled={loading}
          className="mt-4 w-full min-h-[48px] px-5 py-3 rounded-xl bg-gradient-to-r from-[#e5303f] to-[#ff7a45] text-white font-display font-semibold text-base shadow-md shadow-[#e5303f]/25 hover:shadow-lg disabled:opacity-60 inline-flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
        >
          <Search className="w-4 h-4" />
          <span>
            {loading
              ? isEn
                ? 'Loading...'
                : 'กำลังดึงข้อมูล...'
              : isEn
                ? 'Get Clip Info'
                : 'ดูข้อมูลคลิป'}
          </span>
        </button>

        {errorMsg && (
          <p role="alert" className="mt-3 text-sm font-medium text-[#e5303f] dark:text-[#ff6b78]">
            {errorMsg}
          </p>
        )}
      </div>

      {clipInfo && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Thumbnail & Title */}
          <div className="lg:col-span-7 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1a1522] p-5 shadow-xs flex flex-col">
            {clipInfo.thumbnailUrl && !thumbFailed && (
              <div className="aspect-video rounded-xl overflow-hidden bg-slate-900 mb-4 border border-slate-200 dark:border-white/10">
                <img
                  src={clipInfo.thumbnailUrl}
                  alt={isEn ? 'Clip thumbnail' : 'ภาพปกคลิป'}
                  referrerPolicy="no-referrer"
                  onError={() => setThumbFailed(true)}
                  className="w-full h-full object-cover"
                />
              </div>
            )}

            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              {isEn ? 'Clip Title' : 'ชื่อคลิป'}
            </span>
            <p className="mt-1 text-base sm:text-lg font-semibold text-slate-900 dark:text-white break-words">
              {clipInfo.title}
            </p>
            <div className="mt-4">
              <button
                type="button"
                onClick={() => copyText(clipInfo.title, 'title')}
                className={copyBtnClass(copiedKey === 'title')}
              >
                {copiedKey === 'title' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>
                  {copiedKey === 'title'
                    ? isEn
                      ? 'Copied ✓'
                      : 'คัดลอกแล้ว ✓'
                    : isEn
                      ? 'Copy clip title'
                      : 'คัดลอกชื่อคลิป'}
                </span>
              </button>
            </div>
          </div>

          {/* Channel + Quick Actions */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1a1522] p-5 shadow-xs">
              <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
                {isEn ? 'Channel Name' : 'ชื่อช่อง'}
              </span>
              <p className="mt-1 text-base sm:text-lg font-semibold text-slate-900 dark:text-white break-words">
                {clipInfo.channel || (isEn ? 'Unknown channel' : 'ไม่พบชื่อช่อง')}
              </p>
              <div className="mt-4">
                <button
                  type="button"
                  onClick={() => copyText(clipInfo.channel, 'channel')}
                  className={copyBtnClass(copiedKey === 'channel')}
                >
                  {copiedKey === 'channel' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  <span>
                    {copiedKey === 'channel'
                      ? isEn
                        ? 'Copied ✓'
                        : 'คัดลอกแล้ว ✓'
                      : isEn
                        ? 'Copy channel name'
                        : 'คัดลอกชื่อช่อง'}
                  </span>
                </button>
              </div>
            </div>

            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1a1522] p-5 shadow-xs flex flex-col gap-2.5">
              <button
                type="button"
                onClick={() => copyText(`${clipInfo.title} - ${clipInfo.channel}`, 'both')}
                className={`w-full min-h-[46px] px-4 py-2.5 rounded-xl font-display font-semibold text-sm inline-flex items-center justify-center gap-2 transition-all active:scale-[0.98] ${
                  copiedKey === 'both'
                    ? 'bg-gradient-to-r from-[#f97316] to-[#ea580c] text-white shadow-md shadow-orange-500/30'
                    : 'bg-gradient-to-r from-[#f43f5e] to-[#f97316] text-white shadow-sm hover:shadow-md'
                }`}
              >
                {copiedKey === 'both' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>
                  {copiedKey === 'both'
                    ? isEn
                      ? 'Copied ✓'
                      : 'คัดลอกแล้ว ✓'
                    : isEn
                      ? 'Copy both'
                      : 'คัดลอกทั้งสองอย่าง'}
                </span>
              </button>

              <button
                type="button"
                onClick={handleApplyToTag}
                className={`w-full min-h-[46px] px-4 py-2.5 rounded-xl font-display font-semibold text-sm inline-flex items-center justify-center gap-2 transition-all active:scale-[0.98] ${
                  copiedKey === 'apply'
                    ? 'bg-gradient-to-r from-[#f97316] to-[#ea580c] text-white shadow-md shadow-orange-500/30'
                    : 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 hover:opacity-90'
                }`}
              >
                <span>
                  {copiedKey === 'apply'
                    ? isEn
                      ? 'Applied ✓'
                      : 'นำไปใช้แล้ว ✓'
                    : isEn
                      ? 'Use as title/artist in Tag tab'
                      : 'ใช้เป็นชื่อเพลง/ศิลปินในแท็บแท็ก'}
                </span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
