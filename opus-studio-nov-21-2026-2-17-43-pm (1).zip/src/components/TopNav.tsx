import { Menu, Moon, Music2, Sun, X } from 'lucide-react';
import { useState } from 'react';
import type { Lang } from '../data/creditsAndFaq';

export type ActiveView = 'welcome' | 'tag' | 'yt';

interface TopNavProps {
  activeView: ActiveView;
  onNavigate: (view: ActiveView) => void;
  onOpenSheet: (sheet: 'faq' | 'credit') => void;
  lang: Lang;
  onChangeLang: (lang: Lang) => void;
  darkMode: boolean;
  onToggleDark: () => void;
}

export function TopNav({
  activeView,
  onNavigate,
  onOpenSheet,
  lang,
  onChangeLang,
  darkMode,
  onToggleDark,
}: TopNavProps) {
  const [drawerOpen, setDrawerOpen] = useState(false);

  const t = {
    home: lang === 'en' ? 'Home' : 'หน้าแรก',
    tag: lang === 'en' ? 'Tag Music' : 'แท็กเพลง',
    yt: lang === 'en' ? 'YouTube Info' : 'ข้อมูล YouTube',
    faq: lang === 'en' ? 'FAQ' : 'คำถามที่พบบ่อย',
    credit: lang === 'en' ? 'Credits' : 'เครดิต',
    menu: lang === 'en' ? 'Menu' : 'เมนู',
    features: lang === 'en' ? 'Workspace' : 'ฟังก์ชัน',
    more: lang === 'en' ? 'More' : 'เพิ่มเติม',
    theme: lang === 'en' ? (darkMode ? 'Light mode' : 'Dark mode') : darkMode ? 'โหมดสว่าง' : 'โหมดมืด',
    openMenu: lang === 'en' ? 'Open menu' : 'เปิดเมนู',
    closeMenu: lang === 'en' ? 'Close menu' : 'ปิดเมนู',
  };

  const navLinkClass = (active: boolean) =>
    `px-2 py-2 text-sm font-medium transition-colors whitespace-nowrap shrink-0 border-b-2 ${
      active
        ? 'text-[#e5303f] dark:text-[#ff5d6c] border-[#e5303f] dark:border-[#ff5d6c]'
        : 'text-slate-600 dark:text-slate-300 border-transparent hover:text-slate-900 dark:hover:text-white'
    }`;

  return (
    <>
      <header className="sticky top-0 z-30 border-b border-slate-200/80 dark:border-white/10 bg-[#faf8f9]/90 dark:bg-[#120f17]/90 backdrop-blur-md">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4 sm:gap-8">
          {/* Zone 1: Brand wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setDrawerOpen(true)}
              aria-label={t.openMenu}
              aria-expanded={drawerOpen}
              className="md:hidden min-h-[44px] min-w-[44px] inline-flex items-center justify-center rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1c1724] text-slate-800 dark:text-slate-100 hover:border-[#e5303f]/50 transition-colors"
            >
              <Menu className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={() => onNavigate('welcome')}
              className="inline-flex items-center gap-2.5 text-left group whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#e5303f] rounded-lg py-1"
            >
              <span className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#e5303f] to-[#ff7a45] text-white grid place-items-center shadow-sm">
                <Music2 className="w-5 h-5" />
              </span>
              <span className="font-display text-lg font-bold tracking-tight text-slate-900 dark:text-white group-hover:text-[#e5303f] dark:group-hover:text-[#ff6b78] transition-colors">
                Opus Studio
              </span>
            </button>
          </div>

          {/* Zone 2: Clean single-line navigation links */}
          <nav className="hidden md:flex items-center gap-5" aria-label="Main navigation">
            <button type="button" onClick={() => onNavigate('welcome')} className={navLinkClass(activeView === 'welcome')}>
              {t.home}
            </button>
            <button type="button" onClick={() => onNavigate('tag')} className={navLinkClass(activeView === 'tag')}>
              {t.tag}
            </button>
            <button type="button" onClick={() => onNavigate('yt')} className={navLinkClass(activeView === 'yt')}>
              {t.yt}
            </button>
            <button
              type="button"
              onClick={() => onOpenSheet('faq')}
              className={navLinkClass(false)}
            >
              {t.faq}
            </button>
            <button
              type="button"
              onClick={() => onOpenSheet('credit')}
              className={navLinkClass(false)}
            >
              {t.credit}
            </button>
          </nav>

          {/* Zone 3: Language & Theme controls */}
          <div className="flex items-center gap-2 shrink-0">
            <div
              role="group"
              aria-label="Language"
              className="inline-flex p-1 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-100/80 dark:bg-white/5"
            >
              <button
                type="button"
                onClick={() => onChangeLang('th')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  lang === 'th'
                    ? 'bg-gradient-to-r from-[#e5303f] to-[#ff7a45] text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                ไทย
              </button>
              <button
                type="button"
                onClick={() => onChangeLang('en')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  lang === 'en'
                    ? 'bg-gradient-to-r from-[#e5303f] to-[#ff7a45] text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                EN
              </button>
            </div>
            <button
              type="button"
              onClick={onToggleDark}
              aria-label={t.theme}
              title={t.theme}
              className="min-h-[36px] min-w-[36px] inline-flex items-center justify-center rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1c1724] text-slate-700 dark:text-slate-200 hover:border-[#e5303f]/50 transition-colors"
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div
            className="fixed inset-0 bg-black/55 backdrop-blur-xs"
            onClick={() => setDrawerOpen(false)}
            aria-hidden="true"
          />
          <aside
            aria-label={t.menu}
            className="fixed top-0 bottom-0 left-0 w-[min(82vw,320px)] bg-white dark:bg-[#1a1522] border-r border-slate-200 dark:border-white/10 p-5 overflow-y-auto shadow-2xl flex flex-col gap-5"
          >
            <div className="flex items-center justify-between">
              <span className="font-display text-lg font-bold text-slate-900 dark:text-white">{t.menu}</span>
              <button
                type="button"
                onClick={() => setDrawerOpen(false)}
                aria-label={t.closeMenu}
                className="min-h-[44px] min-w-[44px] inline-flex items-center justify-center rounded-xl bg-slate-100 dark:bg-white/10 text-slate-800 dark:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div>
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-2">{t.features}</p>
              <div className="flex flex-col gap-1">
                <button
                  type="button"
                  onClick={() => {
                    onNavigate('welcome');
                    setDrawerOpen(false);
                  }}
                  className="min-h-[44px] px-3 rounded-xl text-left font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-white/10"
                >
                  {t.home}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onNavigate('tag');
                    setDrawerOpen(false);
                  }}
                  className="min-h-[44px] px-3 rounded-xl text-left font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-white/10"
                >
                  {t.tag}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onNavigate('yt');
                    setDrawerOpen(false);
                  }}
                  className="min-h-[44px] px-3 rounded-xl text-left font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-white/10"
                >
                  {t.yt}
                </button>
              </div>
            </div>

            <div className="border-t border-slate-200 dark:border-white/10 pt-4">
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-2">{t.more}</p>
              <div className="flex flex-col gap-1">
                <button
                  type="button"
                  onClick={() => {
                    setDrawerOpen(false);
                    onOpenSheet('faq');
                  }}
                  className="min-h-[44px] px-3 rounded-xl text-left font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-white/10"
                >
                  {t.faq}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setDrawerOpen(false);
                    onOpenSheet('credit');
                  }}
                  className="min-h-[44px] px-3 rounded-xl text-left font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-white/10"
                >
                  {t.credit}
                </button>
              </div>
            </div>
          </aside>
        </div>
      )}
    </>
  );
}
