import { useEffect, useState } from 'react';
import { CreditsSheet } from './components/CreditsSheet';
import { FaqSheet } from './components/FaqSheet';
import { TagEditorTab } from './components/TagEditorTab';
import { TopNav, type ActiveView } from './components/TopNav';
import { WelcomeScreen } from './components/WelcomeScreen';
import { YoutubeInfoTab, type PendingTagPayload } from './components/YoutubeInfoTab';
import type { Lang } from './data/creditsAndFaq';

export default function App() {
  const [activeView, setActiveView] = useState<ActiveView>(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      if (params.get('autostart') === '1') return 'tag';
      if (params.get('tab') === 'yt') return 'yt';
    } catch {
      // ignore
    }
    return 'welcome';
  });

  const [lang, setLang] = useState<Lang>(() => {
    try {
      return localStorage.getItem('lang') === 'en' ? 'en' : 'th';
    } catch {
      return 'th';
    }
  });

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('theme');
      if (saved === 'dark') return true;
      if (saved === 'light') return false;
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    } catch {
      return false;
    }
  });

  const [openSheet, setOpenSheet] = useState<'faq' | 'credit' | null>(null);
  const [pendingTags, setPendingTags] = useState<PendingTagPayload | null>(null);

  useEffect(() => {
    document.documentElement.lang = lang;
    try {
      localStorage.setItem('lang', lang);
    } catch {
      // ignore
    }
  }, [lang]);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
    try {
      localStorage.setItem('theme', darkMode ? 'dark' : 'light');
    } catch {
      // ignore
    }
  }, [darkMode]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && openSheet) {
        setOpenSheet(null);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [openSheet]);

  const navigateTo = (view: ActiveView) => {
    setActiveView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleUseYoutubeInTags = (payload: PendingTagPayload) => {
    setPendingTags(payload);
    navigateTo('tag');
  };

  const isEn = lang === 'en';

  return (
    <div className="min-h-dvh flex flex-col bg-[#faf8f9] dark:bg-[#120f17] text-slate-900 dark:text-slate-100">
      <TopNav
        activeView={activeView}
        onNavigate={navigateTo}
        onOpenSheet={setOpenSheet}
        lang={lang}
        onChangeLang={setLang}
        darkMode={darkMode}
        onToggleDark={() => setDarkMode((d) => !d)}
      />

      <main className="flex-1">
        {activeView === 'welcome' ? (
          <WelcomeScreen
            lang={lang}
            onStart={() => navigateTo('tag')}
            onOpenYoutube={() => navigateTo('yt')}
            onOpenCredits={() => setOpenSheet('credit')}
          />
        ) : (
          <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
            <div className="mb-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
              <div>
                <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
                  {activeView === 'tag'
                    ? isEn
                      ? 'Audio Tag Editor'
                      : 'แก้ไขแท็กเพลง'
                    : isEn
                      ? 'YouTube Clip Info'
                      : 'ดึงข้อมูลคลิป YouTube'}
                </h1>
                <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
                  {activeView === 'tag'
                    ? isEn
                      ? 'Edit .opus, .ogg, and .mp3 metadata and cover artwork directly in your browser.'
                      : 'แก้ชื่อเพลง ศิลปิน อัลบั้ม และภาพปกสำหรับไฟล์ .opus, .ogg และ .mp3'
                    : isEn
                      ? 'Look up clip titles, channels, and thumbnails, then send them to the tag editor.'
                      : 'ดูชื่อคลิป ชื่อช่อง ภาพปก และส่งต่อไปใส่แท็กเพลงได้ในคลิกเดียว'}
                </p>
              </div>

              {/* Workspace segmented tabs */}
              <div
                role="tablist"
                aria-label={isEn ? 'Studio tools' : 'เครื่องมือ'}
                className="inline-flex p-1 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1a1522] shadow-xs self-start"
              >
                <button
                  type="button"
                  role="tab"
                  aria-selected={activeView === 'tag'}
                  onClick={() => navigateTo('tag')}
                  className={`min-h-[40px] px-4 py-1.5 rounded-xl text-sm font-display font-semibold transition-all whitespace-nowrap shrink-0 ${
                    activeView === 'tag'
                      ? 'bg-gradient-to-r from-[#e5303f] to-[#ff7a45] text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {isEn ? 'Tag Music' : 'แท็กเพลง'}
                </button>
                <button
                  type="button"
                  role="tab"
                  aria-selected={activeView === 'yt'}
                  onClick={() => navigateTo('yt')}
                  className={`min-h-[40px] px-4 py-1.5 rounded-xl text-sm font-display font-semibold transition-all whitespace-nowrap shrink-0 ${
                    activeView === 'yt'
                      ? 'bg-gradient-to-r from-[#e5303f] to-[#ff7a45] text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {isEn ? 'YouTube Info' : 'ข้อมูล YouTube'}
                </button>
              </div>
            </div>

            {activeView === 'tag' ? (
              <TagEditorTab
                lang={lang}
                pendingTags={pendingTags}
                onConsumePendingTags={() => setPendingTags(null)}
              />
            ) : (
              <YoutubeInfoTab lang={lang} onUseInTagEditor={handleUseYoutubeInTags} />
            )}
          </div>
        )}
      </main>

      <footer className="border-t border-slate-200/80 dark:border-white/10 py-6 px-4 sm:px-6 text-xs sm:text-sm text-slate-500 dark:text-slate-400">
        <div className="max-w-5xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <span>Opus Studio · {isEn ? 'Audio Tag & YouTube Info Tool' : 'แท็กเพลงและข้อมูลคลิป YouTube'}</span>
          <div className="flex flex-wrap items-center gap-4">
            {typeof window !== 'undefined' &&
              window.location.protocol !== 'file:' &&
              !window.location.pathname.endsWith('.html') && (
                <a
                  href="/download/opus-studio.html"
                  download="opus-studio.html"
                  className="font-semibold text-[#e5303f] dark:text-[#ff6b78] hover:underline"
                >
                  {isEn ? 'Download HTML' : 'ดาวน์โหลดไฟล์เว็บ (.html)'}
                </a>
              )}
            <button
              type="button"
              onClick={() => setOpenSheet('faq')}
              className="hover:text-[#e5303f] dark:hover:text-[#ff6b78] transition-colors"
            >
              {isEn ? 'FAQ' : 'คำถามที่พบบ่อย'}
            </button>
            <button
              type="button"
              onClick={() => setOpenSheet('credit')}
              className="hover:text-[#e5303f] dark:hover:text-[#ff6b78] transition-colors"
            >
              {isEn ? 'Credits' : 'เครดิต'}
            </button>
          </div>
        </div>
      </footer>

      <CreditsSheet open={openSheet === 'credit'} onClose={() => setOpenSheet(null)} lang={lang} />
      <FaqSheet open={openSheet === 'faq'} onClose={() => setOpenSheet(null)} lang={lang} />
    </div>
  );
}
