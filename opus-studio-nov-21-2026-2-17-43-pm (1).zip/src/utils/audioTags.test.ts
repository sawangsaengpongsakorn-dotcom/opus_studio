import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildMp3File,
  buildOpusFile,
  detectAudioFormat,
  oggCrc32,
  parseMp3File,
  parseOpusFile,
  sanitizeDownloadName,
} from './audioTags';
import {
  extractYoutubeVideoId,
  normalizeSpotifyTrackUrl,
  normalizeYoutubeUrl,
  parseYoutubeClipToTags,
} from './mediaHelpers';
import { CREDIT_ITEMS, matchFaqReply } from '../data/creditsAndFaq';

function makeOggPage(
  serial: Uint8Array,
  seq: number,
  headerType: number,
  packet: Uint8Array
): Uint8Array {
  const segments: number[] = [];
  let rem = packet.length;
  while (rem >= 255) {
    segments.push(255);
    rem -= 255;
  }
  segments.push(rem);

  const page = new Uint8Array(27 + segments.length + packet.length);
  const view = new DataView(page.buffer);
  page.set([79, 103, 103, 83, 0, headerType]);
  page.set(serial, 14);
  view.setUint32(18, seq, true);
  page[26] = segments.length;
  page.set(segments, 27);
  page.set(packet, 27 + segments.length);
  view.setUint32(22, 0, true);
  view.setUint32(22, oggCrc32(page), true);
  return page;
}

function makeSyntheticOpusFile(): Uint8Array {
  const te = new TextEncoder();
  const serial = new Uint8Array([1, 2, 3, 4]);
  const opusHead = new Uint8Array(19);
  opusHead.set(te.encode('OpusHead'), 0);
  opusHead[8] = 1;
  opusHead[9] = 2;

  const vendor = te.encode('OpusTest');
  const opusTags = new Uint8Array(8 + 4 + vendor.length + 4);
  const tv = new DataView(opusTags.buffer);
  opusTags.set(te.encode('OpusTags'), 0);
  tv.setUint32(8, vendor.length, true);
  opusTags.set(vendor, 12);
  tv.setUint32(12 + vendor.length, 0, true);

  const audioPacket = new Uint8Array([0x48, 0x01, 0x02, 0x03]);

  const p0 = makeOggPage(serial, 0, 2, opusHead);
  const p1 = makeOggPage(serial, 1, 0, opusTags);
  const p2 = makeOggPage(serial, 2, 4, audioPacket);

  const out = new Uint8Array(p0.length + p1.length + p2.length);
  out.set(p0, 0);
  out.set(p1, p0.length);
  out.set(p2, p0.length + p1.length);
  return out;
}

function makeSyntheticMp3File(): Uint8Array {
  const te = new TextEncoder();
  const frameHeader = new Uint8Array([0xff, 0xfb, 0x90, 0x00, 0x11, 0x22, 0x33, 0x44]);
  const id3v1 = new Uint8Array(128);
  id3v1.set(te.encode('TAG'), 0);
  id3v1.set(te.encode('Old Title'), 3);
  id3v1.set(te.encode('Old Artist'), 33);
  id3v1.set(te.encode('Old Album'), 63);

  const out = new Uint8Array(frameHeader.length + id3v1.length);
  out.set(frameHeader, 0);
  out.set(id3v1, frameHeader.length);
  return out;
}

test('Opus tag round-trip writes and parses Title, Artist, Album, and cover art', () => {
  const raw = makeSyntheticOpusFile();
  assert.equal(detectAudioFormat('song.opus', 'audio/ogg', raw), 'opus');

  const parsed = parseOpusFile(raw);
  const coverBytes = new Uint8Array([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10]);
  const rebuilt = buildOpusFile(
    parsed,
    { title: 'เพลงทดสอบ', artist: 'ศิลปินเอ', album: 'อัลบั้ม 1' },
    { bytes: coverBytes, mime: 'image/jpeg', width: 500, height: 500 }
  );

  const reparsed = parseOpusFile(rebuilt);
  assert.equal(reparsed.tags.title, 'เพลงทดสอบ');
  assert.equal(reparsed.tags.artist, 'ศิลปินเอ');
  assert.equal(reparsed.tags.album, 'อัลบั้ม 1');
  assert.ok(reparsed.cover !== null);
  assert.deepEqual(Array.from(reparsed.cover.bytes), Array.from(coverBytes));
});

test('MP3 ID3v1 fallback and ID3v2.3 round-trip preserves audio and updates tags + cover', () => {
  const raw = makeSyntheticMp3File();
  assert.equal(detectAudioFormat('track.mp3', 'audio/mpeg', raw), 'mp3');

  const parsed = parseMp3File(raw);
  assert.equal(parsed.tags.title, 'Old Title');
  assert.equal(parsed.tags.artist, 'Old Artist');
  assert.equal(parsed.tags.album, 'Old Album');

  const coverBytes = new Uint8Array([0xff, 0xd8, 0xff, 0xdb, 0x12, 0x34]);
  const rebuilt = buildMp3File(
    parsed,
    { title: 'ชื่อใหม่', artist: 'นักร้อง', album: 'ซิงเกิล' },
    { bytes: coverBytes, mime: 'image/jpeg' }
  );

  const reparsed = parseMp3File(rebuilt);
  assert.equal(reparsed.tags.title, 'ชื่อใหม่');
  assert.equal(reparsed.tags.artist, 'นักร้อง');
  assert.equal(reparsed.tags.album, 'ซิงเกิล');
  assert.ok(reparsed.cover !== null);
  assert.deepEqual(Array.from(reparsed.cover.bytes), Array.from(coverBytes));
  assert.deepEqual(Array.from(reparsed.audio), [0xff, 0xfb, 0x90, 0x00, 0x11, 0x22, 0x33, 0x44]);
});

test('YouTube URL normalization, video ID extraction, and tag splitting work cleanly', () => {
  assert.equal(
    normalizeYoutubeUrl('youtu.be/dQw4w9WgXcQ'),
    'https://youtu.be/dQw4w9WgXcQ'
  );
  assert.equal(
    extractYoutubeVideoId('https://www.youtube.com/live/dQw4w9WgXcQ?si=abc'),
    'dQw4w9WgXcQ'
  );
  assert.equal(
    extractYoutubeVideoId('https://www.youtube.com/shorts/dQw4w9WgXcQ'),
    'dQw4w9WgXcQ'
  );
  assert.equal(normalizeYoutubeUrl('https://evil.example.com/watch?v=123'), null);

  assert.equal(
    normalizeSpotifyTrackUrl('open.spotify.com/track/4cOdK2wGLETKBW3PvgPWqT?si=xyz'),
    'https://open.spotify.com/track/4cOdK2wGLETKBW3PvgPWqT'
  );

  const parsedTags = parseYoutubeClipToTags(
    'Artist Name - Song Title [Official MV] (4K)',
    'Artist Name - Topic'
  );
  assert.deepEqual(parsedTags, { artist: 'Artist Name', title: 'Song Title' });

  const fallbackTags = parseYoutubeClipToTags('Just A Song (Lyrics)', 'BandVEVO');
  assert.deepEqual(fallbackTags, { artist: 'Band', title: 'Just A Song' });
});

test('Credits contain exactly 4 unique entries with valid cover paths and FAQ replies match', () => {
  assert.equal(CREDIT_ITEMS.length, 4);
  const ids = new Set(CREDIT_ITEMS.map((c) => c.id));
  assert.equal(ids.size, 4);

  const byId = Object.fromEntries(CREDIT_ITEMS.map((c) => [c.id, c]));
  assert.equal(byId.claude.coverImage, '/assets/aistudio/images__4__07ae82fc.jpeg');
  assert.equal(byId.gemini.coverImage, '/assets/aistudio/images__3__83491943.jpeg');
  assert.equal(byId.narakhnu.coverImage, '/assets/aistudio/alya-1_a8de25fc.jpg');
  assert.equal(byId.pongsakorn.coverImage, '/assets/aistudio/lv_0_20261111140719_295c771a.jpg');

  assert.match(matchFaqReply('เว็บนี้ฟรีไหม', 'th'), /ฟรี/);
  assert.match(matchFaqReply('how to use', 'en'), /Get Started/);
  assert.equal(sanitizeDownloadName('My / Song: *Test*', 'orig.opus', 'opus'), 'My Song Test.opus');
});
