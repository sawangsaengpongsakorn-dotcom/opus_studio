const te = new TextEncoder();
const td = new TextDecoder();

const CRC_TABLE = new Uint32Array(256);
for (let i = 0; i < 256; i++) {
  let c = i << 24;
  for (let k = 0; k < 8; k++) {
    c = (c & 0x80000000) !== 0 ? (c << 1) ^ 0x04c11db7 : c << 1;
  }
  CRC_TABLE[i] = c >>> 0;
}

export function oggCrc32(bytes: Uint8Array): number {
  let c = 0;
  for (let i = 0; i < bytes.length; i++) {
    c = ((c << 8) ^ CRC_TABLE[((c >>> 24) ^ bytes[i]) & 255]) >>> 0;
  }
  return c;
}

function fixOggPage(page: Uint8Array, seq: number): void {
  const view = new DataView(page.buffer, page.byteOffset, page.length);
  view.setUint32(18, seq, true);
  view.setUint32(22, 0, true);
  view.setUint32(22, oggCrc32(page), true);
}

function readAscii(bytes: Uint8Array, offset: number, length: number): string {
  return td.decode(bytes.subarray(offset, offset + length));
}

export interface CoverData {
  bytes: Uint8Array;
  mime: string;
  width?: number;
  height?: number;
}

export interface TagValues {
  title: string;
  artist: string;
  album: string;
}

export interface OggPageMeta {
  offset: number;
  ns: number;
  headerLen: number;
  len: number;
  lastSeg: number;
}

export interface ParsedOpusFile {
  format: 'opus';
  raw: Uint8Array;
  pages: OggPageMeta[];
  tagEndPageIndex: number;
  serial: Uint8Array;
  vendor: Uint8Array;
  comments: string[];
  tags: TagValues;
  cover: CoverData | null;
}

export interface KeptMp3Frame {
  id: string;
  raw: Uint8Array;
}

export interface ParsedMp3File {
  format: 'mp3';
  audio: Uint8Array;
  keptFrames: KeptMp3Frame[];
  tags: TagValues;
  cover: CoverData | null;
}

export type ParsedAudioFile = ParsedOpusFile | ParsedMp3File;

function base64ToBytes(b64: string): Uint8Array {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) {
    out[i] = bin.charCodeAt(i);
  }
  return out;
}

function bytesToBase64(bytes: Uint8Array): string {
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) {
    const chunk = bytes.subarray(i, i + 0x8000);
    s += String.fromCharCode(...chunk);
  }
  return btoa(s);
}

function buildFlacPictureBlock(cover: CoverData): Uint8Array {
  const mimeBytes = te.encode(cover.mime || 'image/jpeg');
  const buf = new Uint8Array(32 + mimeBytes.length + cover.bytes.length);
  const view = new DataView(buf.buffer);
  view.setUint32(0, 3); // Front cover
  view.setUint32(4, mimeBytes.length);
  buf.set(mimeBytes, 8);
  let offset = 8 + mimeBytes.length;
  view.setUint32(offset, 0); // description length
  view.setUint32(offset + 4, cover.width || 0);
  view.setUint32(offset + 8, cover.height || 0);
  view.setUint32(offset + 12, 24);
  view.setUint32(offset + 16, 0);
  offset += 20;
  view.setUint32(offset, cover.bytes.length);
  buf.set(cover.bytes, offset + 4);
  return buf;
}

function parseFlacPictureBlock(b64: string): CoverData | null {
  try {
    const bytes = base64ToBytes(b64);
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.length);
    let offset = 4;
    const mimeLen = view.getUint32(offset);
    offset += 4;
    const mime = readAscii(bytes, offset, mimeLen) || 'image/jpeg';
    offset += mimeLen;
    const descLen = view.getUint32(offset);
    offset += 4 + descLen;
    const width = view.getUint32(offset);
    const height = view.getUint32(offset + 4);
    offset += 16;
    const picLen = view.getUint32(offset);
    offset += 4;
    if (offset + picLen > bytes.length) return null;
    return {
      bytes: bytes.slice(offset, offset + picLen),
      mime,
      width,
      height,
    };
  } catch {
    return null;
  }
}

export function detectAudioFormat(fileName: string, mimeType: string, data: Uint8Array): 'mp3' | 'opus' {
  if (data.length >= 4 && readAscii(data, 0, 4) === 'OggS') {
    return 'opus';
  }
  if (
    /\.mp3$/i.test(fileName) ||
    mimeType === 'audio/mpeg' ||
    mimeType === 'audio/mp3' ||
    (data.length >= 3 && readAscii(data, 0, 3) === 'ID3') ||
    (data.length >= 2 && data[0] === 0xff && (data[1] & 0xe0) === 0xe0)
  ) {
    return 'mp3';
  }
  return 'opus';
}

export function parseOpusFile(data: Uint8Array): ParsedOpusFile {
  const pages: OggPageMeta[] = [];
  for (let offset = 0; offset < data.length; ) {
    if (offset + 27 > data.length || readAscii(data, offset, 4) !== 'OggS') {
      throw new Error('ไม่ใช่ไฟล์ Ogg/Opus หรือ MP3');
    }
    const ns = data[offset + 26];
    if (offset + 27 + ns > data.length) {
      throw new Error('ไม่ใช่ไฟล์ Ogg/Opus หรือ MP3');
    }
    let dataLen = 0;
    for (let i = 0; i < ns; i++) {
      dataLen += data[offset + 27 + i];
    }
    const headerLen = 27 + ns;
    const totalLen = headerLen + dataLen;
    if (offset + totalLen > data.length) {
      throw new Error('ไฟล์ Ogg/Opus เสียหายหรือไม่สมบูรณ์');
    }
    pages.push({
      offset,
      ns,
      headerLen,
      len: totalLen,
      lastSeg: ns > 0 ? data[offset + 26 + ns] : 0,
    });
    offset += totalLen;
  }

  if (pages.length < 2 || readAscii(data, pages[0].offset + pages[0].headerLen, 8) !== 'OpusHead') {
    throw new Error('ไม่ใช่ไฟล์ Opus');
  }

  const serial = data.slice(pages[0].offset + 14, pages[0].offset + 18);
  let k = 1;
  const parts: Uint8Array[] = [];
  for (; k < pages.length; k++) {
    const p = pages[k];
    parts.push(data.subarray(p.offset + p.headerLen, p.offset + p.len));
    if (p.lastSeg < 255) break;
  }
  const tagEndPageIndex = k;

  const totalTagBytes = parts.reduce((acc, part) => acc + part.length, 0);
  const packet = new Uint8Array(totalTagBytes);
  let writePos = 0;
  for (const part of parts) {
    packet.set(part, writePos);
    writePos += part.length;
  }

  if (packet.length < 16 || readAscii(packet, 0, 8) !== 'OpusTags') {
    throw new Error('ไม่พบ OpusTags');
  }

  const view = new DataView(packet.buffer);
  let cursor = 8;
  const vendorLen = view.getUint32(cursor, true);
  cursor += 4;
  const vendor = packet.slice(cursor, cursor + vendorLen);
  cursor += vendorLen;
  const count = view.getUint32(cursor, true);
  cursor += 4;

  const comments: string[] = [];
  for (let i = 0; i < count; i++) {
    const len = view.getUint32(cursor, true);
    cursor += 4;
    comments.push(readAscii(packet, cursor, len));
    cursor += len;
  }

  const getComment = (key: string): string => {
    const upperPrefix = `${key.toUpperCase()}=`;
    const found = comments.find((c) => c.toUpperCase().startsWith(upperPrefix));
    return found ? found.slice(upperPrefix.length) : '';
  };

  const picComment = getComment('METADATA_BLOCK_PICTURE');
  const cover = picComment ? parseFlacPictureBlock(picComment) : null;

  return {
    format: 'opus',
    raw: data,
    pages,
    tagEndPageIndex,
    serial,
    vendor,
    comments,
    tags: {
      title: getComment('TITLE'),
      artist: getComment('ARTIST'),
      album: getComment('ALBUM'),
    },
    cover,
  };
}

export function buildOpusFile(
  parsed: ParsedOpusFile,
  tags: TagValues,
  cover: CoverData | null | undefined
): Uint8Array {
  const cleanTags: Record<string, string> = {
    TITLE: tags.title.trim(),
    ARTIST: tags.artist.trim(),
    ALBUM: tags.album.trim(),
  };

  const nextComments = parsed.comments.filter((comment) => {
    const key = comment.split('=')[0].toUpperCase();
    if (key in cleanTags) return false;
    if (key === 'METADATA_BLOCK_PICTURE' && cover !== undefined) return false;
    return true;
  });

  for (const [key, value] of Object.entries(cleanTags)) {
    if (value) nextComments.push(`${key}=${value}`);
  }
  if (cover) {
    nextComments.push(`METADATA_BLOCK_PICTURE=${bytesToBase64(buildFlacPictureBlock(cover))}`);
  }

  const encodedComments = nextComments.map((c) => te.encode(c));
  const packetLen =
    8 + 4 + parsed.vendor.length + 4 + encodedComments.reduce((sum, item) => sum + 4 + item.length, 0);
  const packet = new Uint8Array(packetLen);
  const view = new DataView(packet.buffer);

  packet.set(te.encode('OpusTags'), 0);
  let cursor = 8;
  view.setUint32(cursor, parsed.vendor.length, true);
  cursor += 4;
  packet.set(parsed.vendor, cursor);
  cursor += parsed.vendor.length;
  view.setUint32(cursor, encodedComments.length, true);
  cursor += 4;
  for (const item of encodedComments) {
    view.setUint32(cursor, item.length, true);
    cursor += 4;
    packet.set(item, cursor);
    cursor += item.length;
  }

  const segments: number[] = [];
  let remaining = packetLen;
  while (remaining >= 255) {
    segments.push(255);
    remaining -= 255;
  }
  segments.push(remaining);

  const chunks: Uint8Array[] = [
    parsed.raw.subarray(parsed.pages[0].offset, parsed.pages[0].offset + parsed.pages[0].len),
  ];

  let seq = 1;
  let packetPos = 0;
  for (let i = 0; i < segments.length; i += 255) {
    const pageSegs = segments.slice(i, i + 255);
    const dataLen = pageSegs.reduce((a, b) => a + b, 0);
    const page = new Uint8Array(27 + pageSegs.length + dataLen);
    const pageView = new DataView(page.buffer);
    page.set([79, 103, 103, 83, 0, i > 0 ? 1 : 0]);
    const isLastTagPage = i + 255 >= segments.length;
    if (!isLastTagPage) {
      pageView.setUint32(6, 0xffffffff, true);
      pageView.setUint32(10, 0xffffffff, true);
    }
    page.set(parsed.serial, 14);
    page[26] = pageSegs.length;
    page.set(pageSegs, 27);
    page.set(packet.subarray(packetPos, packetPos + dataLen), 27 + pageSegs.length);
    packetPos += dataLen;
    fixOggPage(page, seq++);
    chunks.push(page);
  }

  for (let k = parsed.tagEndPageIndex + 1; k < parsed.pages.length; k++) {
    const p = parsed.pages[k];
    const pageCopy = parsed.raw.slice(p.offset, p.offset + p.len);
    fixOggPage(pageCopy, seq++);
    chunks.push(pageCopy);
  }

  const totalOutLen = chunks.reduce((sum, c) => sum + c.length, 0);
  const out = new Uint8Array(totalOutLen);
  let outOffset = 0;
  for (const c of chunks) {
    out.set(c, outOffset);
    outOffset += c.length;
  }
  return out;
}

// ---- MP3 (ID3v2 + ID3v1 fallback) ----

function synchsafeEncode(n: number): number[] {
  return [(n >>> 21) & 0x7f, (n >>> 14) & 0x7f, (n >>> 7) & 0x7f, n & 0x7f];
}

function synchsafeDecode(b: Uint8Array): number {
  return ((b[0] & 0x7f) << 21) | ((b[1] & 0x7f) << 14) | ((b[2] & 0x7f) << 7) | (b[3] & 0x7f);
}

function u32be(n: number): number[] {
  return [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255];
}

function r32be(b: Uint8Array, o: number): number {
  return ((b[o] << 24) | (b[o + 1] << 16) | (b[o + 2] << 8) | b[o + 3]) >>> 0;
}

function decodeId3Text(raw: Uint8Array): string {
  if (!raw || raw.length === 0) return '';
  const enc = raw[0];
  const body = raw.subarray(1);

  if (enc === 0) {
    const end = body.indexOf(0);
    return new TextDecoder('latin1').decode(end >= 0 ? body.subarray(0, end) : body).replace(/\0+$/, '');
  }
  if (enc === 1) {
    let dec: 'utf-16le' | 'utf-16be' = 'utf-16le';
    if (body.length >= 2 && body[0] === 0xfe && body[1] === 0xff) {
      dec = 'utf-16be';
    }
    const hasBom =
      body.length >= 2 &&
      ((body[0] === 0xff && body[1] === 0xfe) || (body[0] === 0xfe && body[1] === 0xff));
    const slice = body.subarray(hasBom ? 2 : 0);
    let end = slice.length;
    for (let i = 0; i + 1 < slice.length; i += 2) {
      if (slice[i] === 0 && slice[i + 1] === 0) {
        end = i;
        break;
      }
    }
    return new TextDecoder(dec).decode(slice.subarray(0, end)).replace(/\0+$/, '');
  }
  if (enc === 2) {
    let end = body.length;
    for (let i = 0; i + 1 < body.length; i += 2) {
      if (body[i] === 0 && body[i + 1] === 0) {
        end = i;
        break;
      }
    }
    return new TextDecoder('utf-16be').decode(body.subarray(0, end)).replace(/\0+$/, '');
  }

  const end = body.indexOf(0);
  return td.decode(end >= 0 ? body.subarray(0, end) : body).replace(/\0+$/, '');
}

function encodeId3TextFrame(id: string, val: string): Uint8Array {
  const txt = te.encode(val);
  const payload = new Uint8Array(1 + txt.length);
  payload[0] = 3; // UTF-8
  payload.set(txt, 1);
  const frame = new Uint8Array(10 + payload.length);
  frame.set(te.encode(id), 0);
  frame.set(u32be(payload.length), 4);
  frame.set(payload, 10);
  return frame;
}

function parseApic(raw: Uint8Array): CoverData | null {
  if (!raw || raw.length < 5) return null;
  const enc = raw[0];
  let p = 1;
  const mimeEnd = raw.indexOf(0, p);
  if (mimeEnd < 0) return null;
  const mime = new TextDecoder('latin1').decode(raw.subarray(p, mimeEnd)) || 'image/jpeg';
  p = mimeEnd + 1;
  if (p >= raw.length) return null;
  p += 1; // skip picture type
  if (enc === 1 || enc === 2) {
    while (p + 1 < raw.length && !(raw[p] === 0 && raw[p + 1] === 0)) {
      p += 2;
    }
    p = Math.min(p + 2, raw.length);
  } else {
    const z = raw.indexOf(0, p);
    p = z >= 0 ? z + 1 : raw.length;
  }
  if (p >= raw.length) return null;
  return {
    bytes: raw.slice(p),
    mime,
  };
}

function encodeApicFrame(cover: CoverData): Uint8Array {
  const mime = te.encode(cover.mime || 'image/jpeg');
  const payloadLen = 1 + mime.length + 1 + 1 + 1 + cover.bytes.length;
  const payload = new Uint8Array(payloadLen);
  let pos = 0;
  payload[pos++] = 0; // ISO-8859-1
  payload.set(mime, pos);
  pos += mime.length;
  payload[pos++] = 0;
  payload[pos++] = 3; // Front cover
  payload[pos++] = 0; // Empty description
  payload.set(cover.bytes, pos);
  const frame = new Uint8Array(10 + payload.length);
  frame.set(te.encode('APIC'), 0);
  frame.set(u32be(payload.length), 4);
  frame.set(payload, 10);
  return frame;
}

export function parseMp3File(buf: Uint8Array): ParsedMp3File {
  let tagSize = 0;
  const tags: TagValues = { title: '', artist: '', album: '' };
  let cover: CoverData | null = null;
  const keptFrames: KeptMp3Frame[] = [];

  if (buf.length >= 10 && readAscii(buf, 0, 3) === 'ID3') {
    const ver = buf[3];
    const flags = buf[5];
    tagSize = 10 + synchsafeDecode(buf.subarray(6, 10));
    let pos = 10;

    if ((flags & 0x40) !== 0 && pos + 4 <= tagSize) {
      const extSize = ver === 4 ? synchsafeDecode(buf.subarray(pos, pos + 4)) : r32be(buf, pos);
      pos += Math.min(extSize, tagSize - pos);
    }

    const end = Math.min(tagSize, buf.length);
    if (ver >= 3) {
      while (pos + 10 <= end) {
        const fid = readAscii(buf, pos, 4);
        if (!/^[A-Z0-9]{4}$/.test(fid)) break;
        const fsize = ver === 4 ? synchsafeDecode(buf.subarray(pos + 4, pos + 8)) : r32be(buf, pos + 4);
        const fflags = (buf[pos + 8] << 8) | buf[pos + 9];
        pos += 10;
        if (fsize <= 0 || pos + fsize > end) break;
        let fdata = buf.subarray(pos, pos + fsize);
        pos += fsize;
        if (ver === 4 && (fflags & 0x0001) !== 0 && fdata.length >= 4) {
          fdata = fdata.subarray(4);
        }
        if (fid === 'TIT2') tags.title = decodeId3Text(fdata);
        else if (fid === 'TPE1') tags.artist = decodeId3Text(fdata);
        else if (fid === 'TALB') tags.album = decodeId3Text(fdata);
        else if (fid === 'APIC') {
          const parsedCover = parseApic(fdata);
          if (parsedCover) cover = parsedCover;
        } else {
          keptFrames.push({ id: fid, raw: new Uint8Array(fdata) });
        }
      }
    }
  }

  const audioStart = tagSize;
  let audioEnd = buf.length;
  if (audioEnd - audioStart >= 128 && readAscii(buf, audioEnd - 128, 3) === 'TAG') {
    const id3v1 = buf.subarray(audioEnd - 128, audioEnd);
    const latin = new TextDecoder('latin1');
    if (!tags.title) tags.title = latin.decode(id3v1.subarray(3, 33)).replace(/\0+$/g, '').trim();
    if (!tags.artist) tags.artist = latin.decode(id3v1.subarray(33, 63)).replace(/\0+$/g, '').trim();
    if (!tags.album) tags.album = latin.decode(id3v1.subarray(63, 93)).replace(/\0+$/g, '').trim();
    audioEnd -= 128;
  }

  if (audioStart >= audioEnd) {
    throw new Error('ไม่พบข้อมูลเสียง MP3');
  }

  return {
    format: 'mp3',
    audio: buf.subarray(audioStart, audioEnd),
    keptFrames,
    tags,
    cover,
  };
}

export function buildMp3File(
  parsed: ParsedMp3File,
  tags: TagValues,
  cover: CoverData | null | undefined
): Uint8Array {
  const frames: Uint8Array[] = [];
  const title = tags.title.trim();
  const artist = tags.artist.trim();
  const album = tags.album.trim();

  if (title) frames.push(encodeId3TextFrame('TIT2', title));
  if (artist) frames.push(encodeId3TextFrame('TPE1', artist));
  if (album) frames.push(encodeId3TextFrame('TALB', album));

  const effectiveCover = cover === undefined ? parsed.cover : cover;
  if (effectiveCover) {
    frames.push(encodeApicFrame(effectiveCover));
  }

  for (const kf of parsed.keptFrames) {
    const fr = new Uint8Array(10 + kf.raw.length);
    fr.set(te.encode(kf.id), 0);
    fr.set(u32be(kf.raw.length), 4);
    fr.set(kf.raw, 10);
    frames.push(fr);
  }

  const bodyLen = frames.reduce((sum, f) => sum + f.length, 0);
  const padLen = 256;
  const totalTagBody = bodyLen + padLen;
  const header = new Uint8Array(10);
  header.set(te.encode('ID3'), 0);
  header[3] = 3; // ID3v2.3
  header[4] = 0;
  header[5] = 0;
  header.set(synchsafeEncode(totalTagBody), 6);

  const out = new Uint8Array(10 + totalTagBody + parsed.audio.length);
  let pos = 0;
  out.set(header, pos);
  pos += 10;
  for (const fr of frames) {
    out.set(fr, pos);
    pos += fr.length;
  }
  pos += padLen;
  out.set(parsed.audio, pos);
  return out;
}

export function sanitizeDownloadName(title: string, originalName: string, format: 'mp3' | 'opus'): string {
  const cleanTitle = title
    .replace(/[\\/:*?"<>|\x00-\x1f]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 120);
  const ext = format === 'mp3' ? '.mp3' : (originalName.match(/\.[^.]+$/) || ['.opus'])[0];
  const base = cleanTitle || originalName.replace(/\.[^.]+$/, '') || 'tagged';
  return `${base}${ext}`;
}
