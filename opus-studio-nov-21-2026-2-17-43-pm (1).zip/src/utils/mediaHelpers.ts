const NOISE_REGEX =
  /[\(\[【\{][^\)\]】\}]*(official|video|mv|m\/v|lyric|audio|visualizer|hd|4k|live|music|เนื้อเพลง|ซับ|เอ็มวี)[^\)\]】\}]*[\)\]】\}]/gi;

export function normalizeYoutubeUrl(raw: string): string | null {
  let trimmed = raw.trim();
  if (!trimmed) return null;
  if (!/^https?:\/\//i.test(trimmed)) {
    if (/^(www\.|m\.|music\.)?(youtube\.com|youtu\.be)\//i.test(trimmed)) {
      trimmed = `https://${trimmed}`;
    } else {
      return null;
    }
  }
  try {
    const parsed = new URL(trimmed);
    const host = parsed.hostname.toLowerCase();
    if (
      host === 'youtube.com' ||
      host === 'www.youtube.com' ||
      host === 'm.youtube.com' ||
      host === 'music.youtube.com' ||
      host === 'youtu.be'
    ) {
      return parsed.toString();
    }
    return null;
  } catch {
    return null;
  }
}

export function extractYoutubeVideoId(url: string): string | null {
  const match = url.match(/(?:youtu\.be\/|v=|shorts\/|embed\/|live\/)([\w-]{11})/);
  return match ? match[1] : null;
}

export function normalizeSpotifyTrackUrl(raw: string): string | null {
  let trimmed = raw.trim();
  if (!trimmed) return null;
  if (!/^https?:\/\//i.test(trimmed)) {
    if (/^open\.spotify\.com\//i.test(trimmed)) {
      trimmed = `https://${trimmed}`;
    } else {
      return null;
    }
  }
  if (!/^https?:\/\/open\.spotify\.com\/.*track\/[A-Za-z0-9]+/i.test(trimmed)) {
    return null;
  }
  return trimmed.split('?')[0];
}

export function parseYoutubeClipToTags(
  clipTitle: string,
  channelName: string
): { title: string; artist: string } {
  const cleanedTitle = clipTitle.replace(NOISE_REGEX, '').replace(/\s+/g, ' ').trim();
  const cleanedChannel = channelName
    .replace(/\s*-\s*Topic$/i, '')
    .replace(/VEVO$/i, '')
    .trim();

  const parts = cleanedTitle.split(/\s+[-–—|]\s+/).filter(Boolean);
  if (parts.length > 1) {
    return {
      artist: parts[0].trim(),
      title: parts.slice(1).join(' - ').trim(),
    };
  }
  return {
    artist: cleanedChannel,
    title: cleanedTitle,
  };
}
