import 'dotenv/config';
import express from 'express';
import type { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = 3000;

function extractYoutubeVideoId(rawUrl: string): string | null {
  const m = rawUrl.match(/(?:youtu\.be\/|v=|shorts\/|embed\/|live\/)([\w-]{11})/);
  return m ? m[1] : null;
}

function isAllowedYoutubeUrl(rawUrl: string): boolean {
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') return false;
    const host = parsed.hostname.toLowerCase();
    return (
      host === 'youtube.com' ||
      host === 'www.youtube.com' ||
      host === 'm.youtube.com' ||
      host === 'music.youtube.com' ||
      host === 'youtu.be'
    );
  } catch {
    return false;
  }
}

function isAllowedSpotifyUrl(rawUrl: string): boolean {
  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') return false;
    return parsed.hostname.toLowerCase() === 'open.spotify.com' && /\/track\/[A-Za-z0-9]+/.test(parsed.pathname);
  } catch {
    return false;
  }
}

const ALLOWED_IMAGE_HOSTS = new Set([
  'i.scdn.co',
  'mosaic.scdn.co',
  'image-cdn-ak.spotifycdn.com',
  'image-cdn-fa.spotifycdn.com',
  'i.ytimg.com',
  'img.youtube.com',
  'yt3.ggpht.com',
]);

function decodeHtmlEntities(input: string): string {
  return input
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&#(\d+);/g, (_, num) => String.fromCharCode(Number(num)));
}

function extractMeta(html: string, key: string): string {
  const re1 = new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]+content=["']([^"']*)["']`, 'i');
  const re2 = new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]+(?:property|name)=["']${key}["']`, 'i');
  const match = html.match(re1) || html.match(re2);
  return match ? decodeHtmlEntities(match[1]) : '';
}

app.get('/api/youtube-info', async (req: Request, res: Response) => {
  const rawUrl = typeof req.query.url === 'string' ? req.query.url.trim() : '';
  if (!rawUrl || !isAllowedYoutubeUrl(rawUrl)) {
    res.status(400).json({ error: 'Invalid YouTube URL' });
    return;
  }

  const videoId = extractYoutubeVideoId(rawUrl);
  const endpoints = [
    `https://www.youtube.com/oembed?format=json&url=${encodeURIComponent(rawUrl)}`,
    `https://noembed.com/embed?url=${encodeURIComponent(rawUrl)}`,
  ];

  for (const endpoint of endpoints) {
    try {
      const response = await fetch(endpoint, {
        headers: { 'User-Agent': 'OpusStudio/1.0' },
        signal: AbortSignal.timeout(8000),
      });
      if (!response.ok) continue;
      const data = (await response.json()) as {
        title?: string;
        author_name?: string;
        thumbnail_url?: string;
      };
      if (data && data.title) {
        res.json({
          title: data.title,
          channel: data.author_name || '',
          videoId: videoId || '',
          thumbnailUrl: videoId
            ? `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`
            : data.thumbnail_url || '',
        });
        return;
      }
    } catch {
      // Try next endpoint
    }
  }

  res.status(404).json({ error: 'Could not fetch clip info' });
});

app.get('/api/spotify-info', async (req: Request, res: Response) => {
  const rawUrl = typeof req.query.url === 'string' ? req.query.url.trim().split('?')[0] : '';
  if (!rawUrl || !isAllowedSpotifyUrl(rawUrl)) {
    res.status(400).json({ error: 'Invalid Spotify track URL' });
    return;
  }

  let title = '';
  let artist = '';
  let thumbnailUrl = '';

  try {
    const oembedRes = await fetch(
      `https://open.spotify.com/oembed?url=${encodeURIComponent(rawUrl)}`,
      { signal: AbortSignal.timeout(8000) }
    );
    if (oembedRes.ok) {
      const data = (await oembedRes.json()) as { title?: string; thumbnail_url?: string };
      title = data.title || '';
      thumbnailUrl = data.thumbnail_url || '';
    }
  } catch {
    // Fallback below
  }

  try {
    const pageRes = await fetch(rawUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; OpusStudio/1.0)',
        'Accept-Language': 'en-US,en;q=0.9',
      },
      signal: AbortSignal.timeout(8000),
    });
    if (pageRes.ok) {
      const html = await pageRes.text();
      if (!title) title = extractMeta(html, 'og:title');
      if (!thumbnailUrl) thumbnailUrl = extractMeta(html, 'og:image');
      artist =
        extractMeta(html, 'music:musician_description') ||
        extractMeta(html, 'og:description').split(' · ')[0] ||
        '';
      if (!artist) {
        const titleTag = decodeHtmlEntities((html.match(/<title>([^<]*)<\/title>/i) || [])[1] || '');
        const byMatch = titleTag.match(/by (.+?)(?: \| Spotify)?$/);
        if (byMatch) artist = byMatch[1];
      }
      artist = artist.trim();
    }
  } catch {
    // Ignore HTML scrape errors if oembed worked
  }

  if (!title && !artist) {
    res.status(404).json({ error: 'Could not fetch Spotify track info' });
    return;
  }

  res.json({ title, artist, thumbnailUrl });
});

app.get('/api/image-proxy', async (req: Request, res: Response) => {
  const rawUrl = typeof req.query.url === 'string' ? req.query.url.trim() : '';
  let parsed: URL;
  try {
    parsed = new URL(rawUrl);
  } catch {
    res.status(400).json({ error: 'Invalid URL' });
    return;
  }

  if (parsed.protocol !== 'https:' || !ALLOWED_IMAGE_HOSTS.has(parsed.hostname.toLowerCase())) {
    res.status(403).json({ error: 'Image host not allowed' });
    return;
  }

  try {
    const imgRes = await fetch(parsed.toString(), { signal: AbortSignal.timeout(8000) });
    if (!imgRes.ok) {
      res.status(imgRes.status).end();
      return;
    }
    const contentType = imgRes.headers.get('content-type') || 'image/jpeg';
    const arrayBuffer = await imgRes.arrayBuffer();
    res.setHeader('Content-Type', contentType);
    res.setHeader('Cache-Control', 'public, max-age=3600');
    res.send(Buffer.from(arrayBuffer));
  } catch {
    res.status(502).json({ error: 'Failed to proxy image' });
  }
});

app.get('/download/opus-studio.html', (_req: Request, res: Response) => {
  const filePath = path.resolve(__dirname, 'public', 'opus-studio.html');
  if (!fs.existsSync(filePath)) {
    res.status(404).send('File not found');
    return;
  }
  res.download(filePath, 'opus-studio.html');
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      const indexFile = path.join(distDir, 'index.html');
      if (fs.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(404).send('Not Found');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Opus Studio server running at http://localhost:${PORT}`);
  });
}

startServer();
